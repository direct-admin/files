<?php
// Security
	  define("liteB105", true);
// create session
	  session_start();

// include		  
	include("settings/vars.php");
  	include("include/mysql1a.php");
	include("include/functions1a.php");
	include("include/PasswordHash.php");
	include("include/geoiploc.php");
	include("include/english1a.php"); 

	$version1 = 'LITE BETA 1.05.01'; // 02-11-2013

	$cdate4 = date("U");
	$cdate3 = date("dmy");		

	$itodaydate = date("Y-m-d");
   	$itodaytime = date("H:i:s");

	$ipaddress = getenv('REMOTE_ADDR');	

	switch (@$_GET['in'])                                   
	{
///////////////////////////////////////////////////////
case "checkdomain":   

		$idomainname = strtolower($maindomain);
		$isubdomainname = trim(strtolower($_REQUEST["domain"]));
		
		$outputmsg = check_domain($isubdomainname);
		if ($outputmsg) {
		$message = $outputmsg ;
		include("include/website1a.php");
		include("include/website2.php");
		exit;
		}	

		$sql = "SELECT id FROM domains WHERE subdomainname1='$isubdomainname' and domainname1='$idomainname' LIMIT 2";       
	   	$result = mysql_query($sql) or die ("Couldn't execute query : " . mysql_error());      
		$num = mysql_num_rows($result);                     
		if ($num == 1) {
			
			$message = '<font color="#FF0000"><b>'.$isubdomainname.'.'.$maindomain.' '.'is not available'.'</b></font>';
			include("include/website1a.php");
			include("include/website2.php");
			exit;
			
		} else {
						
			$message = '<font color="#006600"><b>'.$isubdomainname.'.'.$maindomain.' '.'is available'.'</b></font>
			<br><font size=-1 color="#000000">Registrate and/or Login to registrate this subdomain.</font>';
			include("include/website1a.php");
			include("include/website2.php");
			exit;
			
		}
		
break;
///////////////////////////////////////////////////////
case "newdomain1":

	include("include/check1.php");

	include("include/website1c.php");
	include("include/newdomain1a.php");
	include("include/website2.php");
	exit;		
break;
///////////////////////////////////////////////////////
case "newdomain2":

	include("include/check1.php");

	include("include/newdomain2b.php");
	exit;			
break;
///////////////////////////////////////////////////////
case "domainlock":
	
	include("include/check1.php");

	if ($idomainid == '')
	{
	
	$message = '<font color="#FF0000"><b>Error no id</b></font>';
	include("include/website1a.php");
	include("include/website2.php");
	exit;
	}
	
	$sql107 = "SELECT * FROM domains WHERE id=$idomainid" ;
	$result107 = mysql_query($sql107) or die ("Couldn't execute query : " . mysql_error());
		while ($row107 = mysql_fetch_array($result107))
		{
		extract($row107);
		$idomainlock1 = $domainlock1;
		$iuserid = $userid;
		}	
	
	if ($idomainlock1 == 0) {
	$sql108 = "UPDATE domains SET domainlock1='1' WHERE id=$idomainid" ;
	mysql_query($sql108) or die ("Couldn't execute query : " . mysql_error());
	}
	
	if ($idomainlock1 > 0) {
	$sql109 = "UPDATE domains SET domainlock1='0' WHERE id=$idomainid" ;
	mysql_query($sql109) or die ("Couldn't execute query : " . mysql_error());
	}	
	
	include("include/website1c.php");	
	include("include/domainlist1a.php");
	include("include/website2.php");
	exit;

break;
///////////////////////////////////////////////////////
case "dnsmanage1":

	include("include/check1.php");
	
	if ($iuserid == '')
	{
	
	$message = '<font color="#FF0000"><b>Error no id</b></font>';
	include("include/website1a.php");
	include("include/website2.php");
	exit;
	}
	
	if ($idomainid == '')
	{
	
	$message = '<font color="#FF0000"><b>Error no id</b></font>';
	include("include/website1a.php");
	include("include/website2.php");
	exit;
	}
	
	$sql121 = "SELECT * FROM domains WHERE id=$idomainid LIMIT 1" ;
	$result121 = mysql_query($sql121) or die ("Couldn't execute query : " . mysql_error());
		while ($row121 = mysql_fetch_array($result121))
		{
		extract($row121);
		$isubdomainname1 = $subdomainname1;
		$idomainname1 = $domainname1;
		}	
		
		$isubdomainname2 = $isubdomainname1 . '.' . $idomainname1 ;
		
		include("include/website1c.php");	
		include("include/dns1a.php");
		include("include/website2.php");
		exit;
		
break;
///////////////////////////////////////////////////////
case "settings1":

	include("include/check1.php");

	if ($iuserid == '')
	{
	
	$message = '<font color="#FF0000"><b>Error no id</b></font>';
	
	include("include/website1a.php");
	include("include/website2.php");
	exit;
	}
	
	if ($idomainid == '')
	{
	
	$message = '<font color="#FF0000"><b>Error no id</b></font>';
	include("include/website1a.php");
	include("include/website2.php");
	exit;
	}
	
	$sql122 = "SELECT * FROM domains WHERE id=$idomainid LIMIT 1" ;
	$result122 = mysql_query($sql122) or die ("Couldn't execute query : " . mysql_error());
		while ($row122 = mysql_fetch_array($result122))
		{
		extract($row122);
		$isubdomainname1 = $subdomainname1;
		$idomainname1 = $domainname1;
		$inameserver11 = $nameserver1;
		$inameserver21 = $nameserver2;
		$iipaddress1 = $ipaddress1;
		$iipaddress2 = $ipaddress2;
		$iurl1 = $url1;
		$imicrosoftmx1 = $microsoftmx;
		$igoogletxt1 = $googletxt;
		$iservice1 = $service1;
		}	
		
		$isubdomainname2 = $isubdomainname1 . '.' . $idomainname1 ;
		
		include("include/website1c.php");
		include("include/register5a.php");
		include("include/website2.php");
		exit;

break;
///////////////////////////////////////////////////////
case "profile1":

	include("include/check1.php");

	if ($iuserid == '')
	{
	
	$message = '<font color="#FF0000"><b>Error no id</b></font>';
	include("include/website1a.php");
	include("include/website2.php");
	exit;
	}
	
	if ($idomainid == '')
	{
	
	$message = '<font color="#FF0000"><b>Error no id</b></font>';
	include("include/website1a.php");
	include("include/website2.php");
	exit;
	}
	
	$sql123 = "SELECT * FROM users WHERE id=$iuserid LIMIT 1" ;
	$result123 = mysql_query($sql123) or die ("Couldn't execute query : " . mysql_error());
		while ($row123 = mysql_fetch_array($result123))
		{
		extract($row123);
		$iuserid = $id ;
		$iusername = $username1 ;
		$ifullname1 = $fullname1 ;
		$istreetnumber1 = $streetnumber1 ;
		$ipostcode1 = $postcode1 ;
		$icity1 = $city1 ;
		$icountry1 = $country1 ;
		$iemail1 = $email1 ;	
		}	
		
		include("include/website1c.php");	
		include("include/profile1a.php");
		include("include/website2.php");
		exit;
	
break;
///////////////////////////////////////////////////////
case "passwordchange1":

	include("include/check1.php");

	include("include/website1c.php");
	include("include/passwordchange1.php");
	include("include/website2.php");
	exit;
	
break;
///////////////////////////////////////////////////////
case "passwordchange2":

	include("include/check1.php");

	$ipassword1 = $_REQUEST["password1"];
	$ipassword2 = $_REQUEST["password2"];
	$ipassword3 = $_REQUEST["password3"];
	
	if ($iuserid == '')
	{
	
	$message = '<font color="#FF0000"><b>Error no id</b></font>';
	include("include/website1a.php");
	include("include/website2.php");
	exit;
	}

	if (strlen($ipassword2) < 5) {
	
	$newpasswordmessage = '<font color="#FF0000"><b>Sorry, but this password is too short, minimum length is 5.</b></font>';    
	include("include/website1c.php");
	include("include/passwordchange1.php");
	include("include/website2.php");
	exit;
	}
	
	if ($ipassword2 != $ipassword3) {
	
	$newpasswordmessage = '<font color="#FF0000"><b>Error the passwords you enterd are not equal.</b></font>';
	
	include("include/website1c.php");
	include("include/passwordchange1.php");
	include("include/website2.php");
	exit;
	}	
		
	$sql124 = "SELECT * FROM users WHERE id=$iuserid LIMIT 1" ;
	$result124 = mysql_query($sql124) or die ("Couldn't execute query : " . mysql_error());
		while ($row124 = mysql_fetch_array($result124))
		{
		extract($row124);
		$hash_password3 = $password1;
		}	

	if (validate_password($ipassword1,$hash_password3)) {
		$hash_password = create_hash($ipassword2);
		$sql125 = "UPDATE users SET password1='$hash_password' WHERE password1='$hash_password3' AND id=$iuserid";
		mysql_query($sql125) or die ("Can\'t update database : " . mysql_error());

		$message = '<font color="green"><b>Password changed.</b></font>';
		include("include/website1c.php");	
 		include("include/domainlist1a.php");
		include("include/website2.php");
		exit;	
	
	} else {
		
		$currentpasswordmessage = '<font color="#FF0000"><b>Your old password is not correct.</b></font>';
		include("include/website1c.php");
		include("include/passwordchange1.php");
		include("include/website2.php");
		exit;
	}
	
break;
///////////////////////////////////////////////////////
case "delete":

	include("include/check1.php");

	if ($idomainid == '') {
		$message = '<font color="#FF0000"><b>Error no id</b></font>';
		include("include/website1a.php");
		include("include/website2.php");
		exit;
	}
	
	$sql126 = "SELECT * FROM domains WHERE id=$idomainid LIMIT 1" ;
	$result126 = mysql_query($sql126) or die ("Couldn't execute query : " . mysql_error());
		while ($row126 = mysql_fetch_array($result126))
		{
		extract($row126);
		$isubdomainname10 = $subdomainname1;
		$idomainname10 = $domainname1;
		$idomainlock1 = $domainlock1;
		$iuserid = $userid;
		}
	
	if ($idomainlock1 == 0) {
		
		$sql127 = "DELETE FROM domains WHERE id=$idomainid" ;
    	mysql_query($sql127) or die ("Couldn't execute query : " . mysql_error());
	
		if ($idomainid > 0) {

				$sql129 = "DELETE FROM powerdnsdata1.records WHERE domain_id='$powerdns_domain_id1' AND domainid='$idomainid'" ;
				mysql_query($sql129) or die ("Couldn't execute query : " . mysql_error());
			
				$rdata2 = $dnssoa1." ".date("YmdH")." ".$dnssoa2;
				$sql131 = "UPDATE powerdnsdata1.records set content='$rdata2',change_date=$cdate4 WHERE domain_id=$powerdns_domain_id1 AND type='SOA' AND domainid=0" ;
				mysql_query($sql131) or die ("Couldn't execute query : " . mysql_error());
			
				$message = '<font color="green"><b>'.$isubdomainname10.'.'.$idomainname10.' is removed.</b></font>';
				include("include/website1c.php");	
 				include("include/domainlist1a.php");
				include("include/website2.php");
				exit;

		}
	} else {
	
		$message = "<font color='#FF0000'><b>Domain is Locked !<br>Please unlock the domain prior to delete the domain.</b></font>" ;	
		
		include("include/website1c.php");	
 		include("include/domainlist1a.php");
		include("include/website2.php");
		exit;	
	}
		
break;
///////////////////////////////////////////////////////
case "login":

	include("include/website1b.php");
	include("include/login1a.php");
	include("include/website2.php");
	exit;
	
break;
///////////////////////////////////////////////////////
case "delete9":

	include("include/check1.php");
	
	$idomainrecordid = $_REQUEST["domainrecordid"];
	
	if ( $idomainrecordid != '' ) {
		$sql132 = "SELECT * FROM domains WHERE userid='$iuserid' and id='$idomainid' LIMIT 1";
		$result132 = mysql_query($sql132) or die ("Couldn't execute query : " . mysql_error());
    	$num132 = mysql_num_rows($result132);
    	if ($num132 > 0)  // id's are correct           
    	{
		while ($row132 = mysql_fetch_array($result132))
		{
		extract($row132);
		$isubdomain1 = $subdomainname1;
		$idomainname1 = $domainname1;
		}
		$isubdomainname2 = $isubdomain1.".".$idomainname1 ;
		

$sql134 = "DELETE FROM powerdnsdata1.records WHERE domain_id='$powerdns_domain_id1' AND domainid='$idomainid' AND id='$idomainrecordid'" ;
mysql_query($sql134);

$rdata2 = $dnssoa1." ".date("YmdH")." ".$dnssoa2;
$sql136 = "UPDATE powerdnsdata1.records set content='$rdata2',change_date=$cdate4 WHERE domain_id=$powerdns_domain_id1 AND type='SOA' AND domainid=0" ;
mysql_query($sql136) or die ("Couldn't execute query : " . mysql_error());

		include("include/website1c.php");	
		include("include/dns1a.php");
		include("include/website2.php");
		exit;
		
		} else {  // id not correct           
	  
       	 	$message = "<font color=red>error 201<br></font>";
       	 	include("include/website1a.php");
			include("include/website2.php");
			exit;
      		}
	}
	
break;
///////////////////////////////////////////////////////
case "login1":

	include("include/login2a.php");
	exit;
	
break;
///////////////////////////////////////////////////////
case "login8":

	include("include/check1.php");
	
	if ($iuserid == '')
	{
		$message = '<font color="#FF0000"><b>no user id</b></font>';
		include("include/website1a.php");
		include("include/website2.php");
		exit;
	}
	
	$sql137 = "SELECT username1 FROM users WHERE id='$iuserid' LIMIT 1"; 
    $result137 = mysql_query($sql137) or die ("Couldn't execute query : " . mysql_error());
	$num137 = mysql_num_rows($result137);                     
		if ($num137 == 1) {

		 	include("include/website1c.php");	
		 	include("include/domainlist1a.php");
		 	include("include/website2.php");
		 	exit;		 

		} else {                            

           	$message="<font color=red>incorred user id<br></font>";
           	include("include/website1a.php");
			include("include/website2.php");
		   	exit;
		}                                                    

	
break;
///////////////////////////////////////////////////////
case "login9":

	include("include/check1.php");
	
	include("include/website1c.php");	
	include("include/domainlist1a.php");
	include("include/website2.php");
	exit;		 
	
break;
///////////////////////////////////////////////////////
case "activation1":

	include("include/check1.php");
	
	$iactivationcode2 = $_REQUEST["activation1"];
	
	$sql138 = "SELECT * FROM users WHERE id='$iuserid' LIMIT 1";
    $result138 = mysql_query($sql138) or die ("Couldn't execute query : " . mysql_error());  
    $num138 = mysql_num_rows($result138);
    if ($num138 > 0)          
    {	 
		while ($row138 = mysql_fetch_array($result138))
			{
				extract($row138);
				$iuserid = $id;
				$imaxdomains1 = $maxdomains1;
				$iactivationcode1 = $activationcode1;
			}
		if ($iactivationcode1==$iactivationcode2){
			$sql139 = "UPDATE users SET activationcode1='' WHERE id='$iuserid'";
    		$result139 = mysql_query($sql139) or die ("Couldn't execute query : " . mysql_error());

			$message = "Activation code is excepted.<br>You can now registar a domain.";
			
			include("include/website1c.php");	
			include("include/domainlist1a.php");
			include("include/website2.php");
			exit;	
			
		} else {
			
		    $message = "<font color=#FF0000><b>Activation code is not excepted.<br>You can login and try again.</b></font>";
       	 	include("include/website1a.php");
			include("include/website2.php");
			exit;
		}
		
	} else {
		
	       	$message = "<font color=#FF0000><b>Activation error.<br>You can login and try again.</b></font>";
       	 	include("include/website1a.php");
			include("include/website2.php");
			exit;
	}
	
	include("include/website1a.php");
	include("include/website2.php");
	exit;
	
break;
///////////////////////////////////////////////////////
case "login57":

	include("include/check1.php");
	
	include("include/website1c.php");	
	include("include/domainlist1a.php");
	include("include/website2.php");
	exit;	
	
break;
///////////////////////////////////////////////////////
case "register2":
	
	include("include/website1b.php");
	include("include/register4a.php");
	include("include/website2.php");
	exit;
	
break;
///////////////////////////////////////////////////////
case "registersave2":

	include("include/check1.php");  
	
	include("include/register2b.php");
	exit;
	
break;
///////////////////////////////////////////////////////
case "profile2":

	include("include/check1.php");
	
 	include("include/profile2a.php");
	exit;
	
break;
///////////////////////////////////////////////////////
case "registersave7":

	include("include/check1.php");
	
	include("include/register4b.php");
	exit;
	
break;	
///////////////////////////////////////////////////////
case "logout":

	include("include/check1.php");
	
	include("include/website1a.php");
	include("include/website2.php");
	exit;
	
break;
///////////////////////////////////////////////////////
case "logout9":  

	include("include/website1a.php");
	include("include/website2.php");
	exit;
	
break;	
///////////////////////////////////////////////////////
default:
	$subhost = $_SERVER['HTTP_HOST'];
	$subhost1 = strtolower($subhost);
	$subhost2 = str_replace("www.", "", $subhost1);
	$subhost3 = strstr($subhost2, "/", false);

	if ($subhost3) { $subhost = str_replace($subhost3, "", $subhost); }
	if ($subhost2=="$maindomain" || $subhost2=="www.$maindomain") {
		include("include/website1a.php");
		include("include/website2.php");
		exit;
	}
	if ($_SERVER['REQUEST_URI']=="/") { $subhost3 = ""; } else { $subhost3 = $_SERVER['REQUEST_URI']; }
	$maindomain3 = '.'.$maindomain ;
	$subhost4 = str_replace($maindomain3, "", $subhost2);

	$sql140 = "SELECT * FROM domains WHERE subdomainname1 = '$subhost4' and service1='forwarding' LIMIT 1";
   	$result140 = mysql_query($sql140) or die ("Couldn't execute query : " . mysql_error());
	if (mysql_num_rows($result140) != 1) {
		$subhost5 = "http://www.".$maindomain."/index.php?in=checkdomain&domain=".$subhost4 ;
		header("Location: ".$subhost5."");
		exit;

	}
	$row140 = mysql_fetch_array($result140);
	$target_url = "$row140[url1]$subhost3";

	header ("Location: $target_url");
	exit;

break;
///////////////////////////////////////////////////////
}        
?>