<?php
###################################################################
################  Language English  ###############################
###################################################################
$bot_Home = "Home";
$bot_Domainlist = "Domainlist";

$top_Version = "Version :";
$top_Logout = "Logout";
$top_My_Account = "My Account";
$top_Create_a_new_account = "Create a new account";

$example_www_yourname = "example : www.yourname."; 

$dlist_Active = "Active";
$dlist_Domain = "Domain";
$dlist_delete_account = "delete account";
$dlist_Settings = "Settings";
$dlist_DNS = "DNS";
$dlist_Lock = "Lock";
$dlist_Delete = "Delete";
$dlist_Created = "Created on";
$dlist_My_Profile = "My Profile";
$dlist_My_Password = "My Password";
$dlist_New_Domain = "New Domain";
$dlist_My_Domains = "My Domains";
$Login = "Login";
$dlist_Logout = "Logout";
$dlist_You_dont_have_any_domains_yet = "You don't have any domains yet.";

$dlist_Host = "Host";
$dlist_TTL = "TTL";
$dlist_type = "type";
$dlist_data = "data";
$dlist_Prio = "Prio";
$dlist_Date = "Date";
$dlist_Delete = "Delete";
$dlist_Create_Zone_Record = "Create Zone Record";
$dlist_back_to_domainlist = "back to domainlist";
$dlist_Your_current_Zone_Records = "Your current Zone Records :";
$dlist_setting_up_Zone_Records_your_domain = "You are setting up the Zone Records for your domain :";
$dlist_Zone_Records_Setup_NS_A_CNAME_MX_SOA_AAAA  = "Zone Records Setup (NS, A, CNAME, MX, SOA and new AAAA)";
$dlist_Important = 
"Important: It may take up to 48 hours for changes made to our zone records to become effective.<br>
This is because of the number of networks and agencies involved.<br>
Delays apply to all domains and registrars.<br>
Please allow for this delay when planning Web sites or configuring a domain to work with your email.";

$abuse_The_code_you_entered_was_invalid = "The code you entered was invalid.";
$abuse_Massage_has_been_send = "Massage has been send.";
$abuse_domain_not_found = "domain not found";
$abuse_more_domains_found = "more domains found";

$Activate_your_account = "Activate your account.";
$Please_enter_here_your_activation_code_in = "Please enter here your activation code in :";

$If_you_do_not_have_an_account = "If you do not have an account already klik hier to make a account";

$No_Settings = "No Settings";
$Name_Servers = "Name Servers";
$Name_Server_1 ="Name Server 1 : ";
$Name_Server_2 ="Name Server 2 : ";
$Zone_Record = "Zone Record";
$IPv4_address = "IPv4 address :";
$IPv6_address = "IPv6 address :";
$URL_Forwarding = "URL Forwarding";
$Redirect_To_URL = "Redirect To (URL) :";
$Include_HTTP = "Include HTTP://";
$Registar_Save = "Registar/Save";

$My_Account_Login = "My Account Login";

$Username = "Username* :";
$Password = "Password* :";
$Repeat_Password = "Repeat Password* :";
$Full_Name = "Full Name* :";
$Street_Nr = "Street / Number* :";
$PostCode = "Post Code :";
$City = "City* :";
$Country = "Country* :";
$Email = "Email* :";
$Security_Code = "Security Code :";
$Verify_Code = "Verify Code* :";
$Enter_Code = "Enter Code*:";
$Create_Account = "Create Account";
$Back = "Back";

$create_a_new_account = "create a new account";
$Save_Account = "Save Account";
$Chance_your_account = "Change your account";

$Chance_your_password = "Change your password";
$Your_current_password = "Your current Password : ";
$Your_new_password = "Your new Password : ";
$Repeat_your_new_password = "Repeat your new Password : ";
$Save_New_Password = "Save New Password";

$Important = "Important :";

$Your_Password = "Your Password :";

$nd_Registrate_a_new_domain = "Registrate a new domain";
$nd_Enter_the_domainname_your_want_to_registrate = "Enter the domainname your want to registrate";
$nd_Registrate_new_domain = "Registrate new domain";

$Login_here = "Login here :";
$Domeinname = "domainname :";

$Please_enter_your_desired_domain_name = "Please enter your desired domain name without any extension and click on \"check availability\" <br>(spaces and $&+,/.:;=?@<>#%{}|\^~[]` characters are not allowed.)";

$ERR_Sorry_used_one_more_characters_are_not_allowed = "Sorry, but you used one or more of this characters $&+,/.:;=?@<>#%{}|\^~[]`, and they are not allowed.";
$ERR_Sorry_domain_name_too_short_or_too_long_length_your_domainname = "Sorry, but this domain name is too short or too long.<br>Be aware, that minimum length of your domainname is";

$ERR_and_maximum_is = "and maximum is";

##################################################################################################################
################################################ End #############################################################
##################################################################################################################
?>