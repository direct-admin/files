<link href="../css/style.css" rel="stylesheet" type="text/css">
<?php
if(define("liteB105", false)) die("Hacking System");

#######################

		$adata = "";
		$tekens1 = array_merge(range('A', 'Z'), range(0, 9));
		for ($i1 = 0; $i1 < 8; $i1++) { $adata .= $tekens1[rand(0, count($tekens1) - 1)]; }
		$auserid1 = $iuserid;
		$adomainid1 = 0;
		$adate1 = date("dmy");

		$sql1 = "INSERT INTO data1 ( data, userid, domainid, date) VALUES ('$adata', $auserid1, $adomainid1, '$adate1')";
		mysql_query($sql1) or die ("no. 1 Couldn't execute query : " . mysql_error());				

#######################

print "<br>".$message."<br>";

?>
</center>
    <br />
    <form name="form01" method="post" action="../index.php?in=profile2">
    <input type="hidden" name="data" value="<?php echo @$adata ?>">
<table border="0" align="center">
    <tr>
      <td colspan="3" class="text2"><?php echo "$Chance_your_account"; ?></td>
      </tr>
    <tr>
      <td colspan="3">Important:<br>
You must enter your real contact details below.<br>
It is strictly forbidden to have more then 1 account per person.<br>
<u>Accounts which do not comply with these two rules will be deleted without warning.</u><br>
<i>Fields marked like this * are required fields</i></td>
      </tr>
    <tr>
      <td >&nbsp;</td>
      <td >&nbsp;</td>
      <td >&nbsp;</td>
    </tr>
    <tr>
      <td><?php echo "$Username"; ?></td>
      <td>&nbsp;</td>
      <td><input name="username1" class="input1" type="text" value='<?php echo "$iusername"; ?>' size="40" maxlength="40"></td>
    </tr>
<?php                                                   
if (isset($usernamemessage)) { Print "
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>".$usernamemessage."</td>
    </tr> "; }
?>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><?php echo "$Full_Name"; ?></td>
      <td>&nbsp;</td>
      <td><input name="fullname1" type="text" class="input1" value='<?php echo "$ifullname1"; ?>' size="70" maxlength="70" /></td>
    </tr>
<?php                                                   
if (isset($namemessage)) { Print "
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>".$namemessage."</td>
    </tr>";
}
?> 
    <tr>
      <td><?php echo "$Street_Nr"; ?></td>
      <td>&nbsp;</td>
      <td><input name="streetnumber1" type="text" class="input1" value='<?php echo "$istreetnumber1"; ?>' size="70" maxlength="70" /></td>
    </tr>
<?php                                                   
if (isset($streetmessage)) { Print "
   <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>".$streetmessage."</td>
    </tr>";
}
?>    
    <tr>
      <td><?php echo "$PostCode"; ?></td>
      <td>&nbsp;</td>
      <td><input name="postcode1" type="text" class="input1" value='<?php echo "$ipostcode1"; ?>' size="40" maxlength="40" /></td>
    </tr>
<?php                                                   
if (isset($postcodemessage)) { Print "
   <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>".$postcodemessage."</td>
    </tr>";
}
?>   
    <tr>
      <td><?php echo "$City"; ?></td>
      <td>&nbsp;</td>
      <td><input name="city1" type="text" class="input1" value='<?php echo "$icity1"; ?>' size="50" maxlength="50" /></td>
    </tr>
<?php                                                   
if (isset($citymessage)) { Print " 
   <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>".$citymessage."</td>
    </tr>";  
}
?>  
    <tr>
      <td><?php echo "$Country"; ?></td>
      <td>&nbsp;</td>
      <td>
<select name="country1" id="country" class="input1">
<option value=""<?php if ($icountry1=="") { print " selected" ; } ?>></option>
<option value="Afghanistan"<?php if ($icountry1=="Afghanistan") { print  selected ; } ?>>Afghanistan</option>
<option value="Aland Islands"<?php if ($icountry1=="Aland Islands") { print  selected ; } ?>>Aland Islands</option>
<option value="Albania"<?php if ($icountry1=="Albania") { print  selected ; } ?>>Albania</option>
<option value="Algeria"<?php if ($icountry1=="Algeria") { print  selected ; } ?>>Algeria</option>
<option value="American Samoa"<?php if ($icountry1=="American Samoa") { print  selected ; } ?>>American Samoa</option>
<option value="Andorra"<?php if ($icountry1=="Andorra") { print  selected ; } ?>>Andorra</option>
<option value="Angola"<?php if ($icountry1=="Angola") { print  selected ; } ?>>Angola</option>
<option value="Anguilla"<?php if ($icountry1=="Anguilla") { print  selected ; } ?>>Anguilla</option>
<option value="Anonymous Proxy"<?php if ($icountry1=="Anonymous Proxy") { print  selected ; } ?>>Anonymous Proxy</option>
<option value="Antarctica"<?php if ($icountry1=="Antarctica") { print  selected ; } ?>>Antarctica</option>
<option value="Antigua and Barbuda"<?php if ($icountry1=="Antigua and Barbuda") { print  selected ; } ?>>Antigua and Barbuda</option>
<option value="Argentina"<?php if ($icountry1=="Argentina") { print  selected ; } ?>>Argentina</option>
<option value="Armenia"<?php if ($icountry1=="Armenia") { print  selected ; } ?>>Armenia</option>
<option value="Aruba"<?php if ($icountry1=="Aruba") { print  selected ; } ?>>Aruba</option>
<option value="Asia/Pacific Region"<?php if ($icountry1=="Asia/Pacific Region") { print  selected ; } ?>>Asia/Pacific Region</option>
<option value="Australia"<?php if ($icountry1=="Australia") { print  selected ; } ?>>Australia</option>
<option value="Austria"<?php if ($icountry1=="Austria") { print  selected ; } ?>>Austria</option>
<option value="Azerbaijan"<?php if ($icountry1=="Azerbaijan") { print  selected ; } ?>>Azerbaijan</option>
<option value="Bahamas"<?php if ($icountry1=="Bahamas") { print  selected ; } ?>>Bahamas</option>
<option value="Bahrain"<?php if ($icountry1=="Bahrain") { print  selected ; } ?>>Bahrain</option>
<option value="Bangladesh"<?php if ($icountry1=="Bangladesh") { print  selected ; } ?>>Bangladesh</option>
<option value="Barbados"<?php if ($icountry1=="Barbados") { print  selected ; } ?>>Barbados</option>
<option value="Belarus"<?php if ($icountry1=="Belarus") { print  selected ; } ?>>Belarus</option>
<option value="Belgium"<?php if ($icountry1=="Belgium") { print  selected ; } ?>>Belgium</option>
<option value="Belize"<?php if ($icountry1=="Belize") { print  selected ; } ?>>Belize</option>
<option value="Benin"<?php if ($icountry1=="Benin") { print  selected ; } ?>>Benin</option>
<option value="Bermuda"<?php if ($icountry1=="Bermuda") { print  selected ; } ?>>Bermuda</option>
<option value="Bhutan"<?php if ($icountry1=="Bhutan") { print  selected ; } ?>>Bhutan</option>
<option value="Bolivia"<?php if ($icountry1=="Bolivia") { print  selected ; } ?>>Bolivia</option>
<option value="Bosnia and Herzegovina"<?php if ($icountry1=="Bosnia and Herzegovina") { print  selected ; } ?>>Bosnia and Herzegovina</option>
<option value="Botswana"<?php if ($icountry1=="Botswana") { print  selected ; } ?>>Botswana</option>
<option value="Bouvet Island"<?php if ($icountry1=="Bouvet Island") { print  selected ; } ?>>Bouvet Island</option>
<option value="Brazil"<?php if ($icountry1=="Brazil") { print  selected ; } ?>>Brazil</option>
<option value="British Indian Ocean Territory"<?php if ($icountry1=="British Indian Ocean Territory") { print  selected ; } ?>>British Indian Ocean Territory</option>
<option value="Brunei Darussalam"<?php if ($icountry1=="Brunei Darussalam") { print  selected ; } ?>>Brunei Darussalam</option>
<option value="Bulgaria"<?php if ($icountry1=="Bulgaria") { print  selected ; } ?>>Bulgaria</option>
<option value="Burkina Faso"<?php if ($icountry1=="Burkina Faso") { print  selected ; } ?>>Burkina Faso</option>
<option value="Burundi"<?php if ($icountry1=="Burundi") { print  selected ; } ?>>Burundi</option>
<option value="Cambodia"<?php if ($icountry1=="Cambodia") { print  selected ; } ?>>Cambodia</option>
<option value="Cameroon"<?php if ($icountry1=="Cameroon") { print  selected ; } ?>>Cameroon</option>
<option value="Canada"<?php if ($icountry1=="Canada") { print  selected ; } ?>>Canada</option>
<option value="Cape Verde"<?php if ($icountry1=="Cape Verde") { print  selected ; } ?>>Cape Verde</option>
<option value="Cayman Islands"<?php if ($icountry1=="Cayman Islands") { print  selected ; } ?>>Cayman Islands</option>
<option value="Central African Republic"<?php if ($icountry1=="Central African Republic") { print  selected ; } ?>>Central African Republic</option>
<option value="Chad"<?php if ($icountry1=="Chad") { print  selected ; } ?>>Chad</option>
<option value="Chile"<?php if ($icountry1=="Chile") { print  selected ; } ?>>Chile</option>
<option value="China"<?php if ($icountry1=="China") { print  selected ; } ?>>China</option>
<option value="Colombia"<?php if ($icountry1=="Colombia") { print  selected ; } ?>>Colombia</option>
<option value="Comoros"<?php if ($icountry1=="Comoros") { print  selected ; } ?>>Comoros</option>
<option value="Congo"<?php if ($icountry1=="Congo") { print  selected ; } ?>>Congo</option>
<option value="Congo, The Democratic Republic of the"<?php if ($icountry1=="Congo, The Democratic Republic of the") { print  selected ; } ?>>Congo, The Democratic Republic of the</option>
<option value="Cook Islands"<?php if ($icountry1=="Cook Islands") { print  selected ; } ?>>Cook Islands</option>
<option value="Costa Rica"<?php if ($icountry1=="Costa Rica") { print  selected ; } ?>>Costa Rica</option>
<option value="Cote D'Ivoire"<?php if ($icountry1=="Cote D'Ivoire") { print  selected ; } ?>>Cote D'Ivoire</option>
<option value="Croatia"<?php if ($icountry1=="Croatia") { print  selected ; } ?>>Croatia</option>
<option value="Cuba"<?php if ($icountry1=="Cuba") { print  selected ; } ?>>Cuba</option>
<option value="Cyprus"<?php if ($icountry1=="Cyprus") { print  selected ; } ?>>Cyprus</option>
<option value="Czech Republic"<?php if ($icountry1=="Czech Republic") { print  selected ; } ?>>Czech Republic</option>
<option value="Denmark"<?php if ($icountry1=="Denmark") { print  selected ; } ?>>Denmark</option>
<option value="Djibouti"<?php if ($icountry1=="Djibouti") { print  selected ; } ?>>Djibouti</option>
<option value="Dominica"<?php if ($icountry1=="Dominica") { print  selected ; } ?>>Dominica</option>
<option value="Dominican Republic"<?php if ($icountry1=="Dominican Republic") { print  selected ; } ?>>Dominican Republic</option>
<option value="Ecuador"<?php if ($icountry1=="Ecuador") { print  selected ; } ?>>Ecuador</option>
<option value="Egypt"<?php if ($icountry1=="Egypt") { print  selected ; } ?>>Egypt</option>
<option value="El Salvador"<?php if ($icountry1=="El Salvador") { print  selected ; } ?>>El Salvador</option>
<option value="Equatorial Guinea"<?php if ($icountry1=="Equatorial Guinea") { print  selected ; } ?>>Equatorial Guinea</option>
<option value="Eritrea"<?php if ($icountry1=="Eritrea") { print  selected ; } ?>>Eritrea</option>
<option value="Estonia"<?php if ($icountry1=="Estonia") { print  selected ; } ?>>Estonia</option>
<option value="Ethiopia"<?php if ($icountry1=="Ethiopia") { print  selected ; } ?>>Ethiopia</option>
<option value="Europe"<?php if ($icountry1=="Europe") { print  selected ; } ?>>Europe</option>
<option value="Falkland Islands (Malvinas)"<?php if ($icountry1=="Falkland Islands (Malvinas)") { print  selected ; } ?>>Falkland Islands (Malvinas)</option>
<option value="Faroe Islands"<?php if ($icountry1=="Faroe Islands") { print  selected ; } ?>>Faroe Islands</option>
<option value="Fiji"<?php if ($icountry1=="Fiji") { print  selected ; } ?>>Fiji</option>
<option value="Finland"<?php if ($icountry1=="Finland") { print  selected ; } ?>>Finland</option>
<option value="France"<?php if ($icountry1=="France") { print  selected ; } ?>>France</option>
<option value="French Guiana"<?php if ($icountry1=="French Guiana") { print  selected ; } ?>>French Guiana</option>
<option value="French Polynesia"<?php if ($icountry1=="French Polynesia") { print  selected ; } ?>>French Polynesia</option>
<option value="Gabon"<?php if ($icountry1=="Gabon") { print  selected ; } ?>>Gabon</option>
<option value="Gambia"<?php if ($icountry1=="Gambia") { print  selected ; } ?>>Gambia</option>
<option value="Georgia"<?php if ($icountry1=="Georgia") { print  selected ; } ?>>Georgia</option>
<option value="Germany"<?php if ($icountry1=="Germany") { print  selected ; } ?>>Germany</option>
<option value="Ghana"<?php if ($icountry1=="Ghana") { print  selected ; } ?>>Ghana</option>
<option value="Gibraltar"<?php if ($icountry1=="Gibraltar") { print  selected ; } ?>>Gibraltar</option>
<option value="Greece"<?php if ($icountry1=="Greece") { print  selected ; } ?>>Greece</option>
<option value="Greenland"<?php if ($icountry1=="Greenland") { print  selected ; } ?>>Greenland</option>
<option value="Grenada"<?php if ($icountry1=="Grenada") { print  selected ; } ?>>Grenada</option>
<option value="Guadeloupe"<?php if ($icountry1=="Guadeloupe") { print  selected ; } ?>>Guadeloupe</option>
<option value="Guam"<?php if ($icountry1=="Guam") { print  selected ; } ?>>Guam</option>
<option value="Guatemala"<?php if ($icountry1=="Guatemala") { print  selected ; } ?>>Guatemala</option>
<option value="Guernsey"<?php if ($icountry1=="Guernsey") { print  selected ; } ?>>Guernsey</option>
<option value="Guinea"<?php if ($icountry1=="Guinea") { print  selected ; } ?>>Guinea</option>
<option value="Guinea-Bissau"<?php if ($icountry1=="Guinea-Bissau") { print  selected ; } ?>>Guinea-Bissau</option>
<option value="Guyana"<?php if ($icountry1=="Guyana") { print  selected ; } ?>>Guyana</option>
<option value="Haiti"<?php if ($icountry1=="Haiti") { print  selected ; } ?>>Haiti</option>
<option value="Holy See (Vatican City State)"<?php if ($icountry1=="Holy See (Vatican City State)") { print  selected ; } ?>>Holy See (Vatican City State)</option>
<option value="Honduras"<?php if ($icountry1=="Honduras") { print  selected ; } ?>>Honduras</option>
<option value="Hong Kong"<?php if ($icountry1=="Hong Kong") { print  selected ; } ?>>Hong Kong</option>
<option value="Hungary"<?php if ($icountry1=="Hungary") { print  selected ; } ?>>Hungary</option>
<option value="Iceland"<?php if ($icountry1=="Iceland") { print  selected ; } ?>>Iceland</option>
<option value="India"<?php if ($icountry1=="India") { print  selected ; } ?>>India</option>
<option value="Indonesia"<?php if ($icountry1=="Indonesia") { print  selected ; } ?>>Indonesia</option>
<option value="Iran, Islamic Republic of"<?php if ($icountry1=="Iran, Islamic Republic of") { print  selected ; } ?>>Iran, Islamic Republic of</option>
<option value="Iraq"<?php if ($icountry1=="Iraq") { print  selected ; } ?>>Iraq</option>
<option value="Ireland"<?php if ($icountry1=="Ireland") { print  selected ; } ?>>Ireland</option>
<option value="Isle of Man"<?php if ($icountry1=="Isle of Man") { print  selected ; } ?>>Isle of Man</option>
<option value="Israel"<?php if ($icountry1=="Israel") { print  selected ; } ?>>Israel</option>
<option value="Italy"<?php if ($icountry1=="Italy") { print  selected ; } ?>>Italy</option>
<option value="Jamaica"<?php if ($icountry1=="Jamaica") { print  selected ; } ?>>Jamaica</option>
<option value="Japan"<?php if ($icountry1=="Japan") { print  selected ; } ?>>Japan</option>
<option value="Jersey"<?php if ($icountry1=="Jersey") { print  selected ; } ?>>Jersey</option>
<option value="Jordan"<?php if ($icountry1=="Jordan") { print  selected ; } ?>>Jordan</option>
<option value="Kazakhstan"<?php if ($icountry1=="Kazakhstan") { print  selected ; } ?>>Kazakhstan</option>
<option value="Kenya"<?php if ($icountry1=="Kenya") { print  selected ; } ?>>Kenya</option>
<option value="Kiribati"<?php if ($icountry1=="Kiribati") { print  selected ; } ?>>Kiribati</option>
<option value="Korea, Democratic People's Republic of"<?php if ($icountry1=="Korea, Democratic People's Republic of") { print  selected ; } ?>>Korea, Democratic People's Republic of</option>
<option value="Korea, Republic of"<?php if ($icountry1=="Korea, Republic of") { print  selected ; } ?>>Korea, Republic of</option>
<option value="Kuwait"<?php if ($icountry1=="Kuwait") { print  selected ; } ?>>Kuwait</option>
<option value="Kyrgyzstan"<?php if ($icountry1=="Kyrgyzstan") { print  selected ; } ?>>Kyrgyzstan</option>
<option value="Lao People's Democratic Republic"<?php if ($icountry1=="Lao People's Democratic Republic") { print  selected ; } ?>>Lao People's Democratic Republic</option>
<option value="Latvia"<?php if ($icountry1=="Latvia") { print  selected ; } ?>>Latvia</option>
<option value="Lebanon"<?php if ($icountry1=="Lebanon") { print  selected ; } ?>>Lebanon</option>
<option value="Lesotho"<?php if ($icountry1=="Lesotho") { print  selected ; } ?>>Lesotho</option>
<option value="Liberia"<?php if ($icountry1=="Liberia") { print  selected ; } ?>>Liberia</option>
<option value="Libyan Arab Jamahiriya"<?php if ($icountry1=="Libyan Arab Jamahiriya") { print  selected ; } ?>>Libyan Arab Jamahiriya</option>
<option value="Liechtenstein"<?php if ($icountry1=="Liechtenstein") { print  selected ; } ?>>Liechtenstein</option>
<option value="Lithuania"<?php if ($icountry1=="Lithuania") { print  selected ; } ?>>Lithuania</option>
<option value="Luxembourg"<?php if ($icountry1=="Luxembourg") { print  selected ; } ?>>Luxembourg</option>
<option value="Macau"<?php if ($icountry1=="Macau") { print  selected ; } ?>>Macau</option>
<option value="Macedonia"<?php if ($icountry1=="Macedonia") { print  selected ; } ?>>Macedonia</option>
<option value="Madagascar"<?php if ($icountry1=="Madagascar") { print  selected ; } ?>>Madagascar</option>
<option value="Malawi"<?php if ($icountry1=="Malawi") { print  selected ; } ?>>Malawi</option>
<option value="Malaysia"<?php if ($icountry1=="Malaysia") { print  selected ; } ?>>Malaysia</option>
<option value="Maldives"<?php if ($icountry1=="Maldives") { print  selected ; } ?>>Maldives</option>
<option value="Mali"<?php if ($icountry1=="Mali") { print  selected ; } ?>>Mali</option>
<option value="Malta"<?php if ($icountry1=="Malta") { print  selected ; } ?>>Malta</option>
<option value="Marshall Islands"<?php if ($icountry1=="Marshall Islands") { print  selected ; } ?>>Marshall Islands</option>
<option value="Martinique"<?php if ($icountry1=="Martinique") { print  selected ; } ?>>Martinique</option>
<option value="Mauritania"<?php if ($icountry1=="Mauritania") { print  selected ; } ?>>Mauritania</option>
<option value="Mauritius"<?php if ($icountry1=="Mauritius") { print  selected ; } ?>>Mauritius</option>
<option value="Mayotte"<?php if ($icountry1=="Mayotte") { print  selected ; } ?>>Mayotte</option>
<option value="Mexico"<?php if ($icountry1=="Mexico") { print  selected ; } ?>>Mexico</option>
<option value="Micronesia, Federated States of"<?php if ($icountry1=="Micronesia, Federated States of") { print  selected ; } ?>>Micronesia, Federated States of</option>
<option value="Moldova, Republic of"<?php if ($icountry1=="Moldova, Republic of") { print  selected ; } ?>>Moldova, Republic of</option>
<option value="Monaco"<?php if ($icountry1=="Monaco") { print  selected ; } ?>>Monaco</option>
<option value="Mongolia"<?php if ($icountry1=="Mongolia") { print  selected ; } ?>>Mongolia</option>
<option value="Montenegro"<?php if ($icountry1=="Montenegro") { print  selected ; } ?>>Montenegro</option>
<option value="Montserrat"<?php if ($icountry1=="Montserrat") { print  selected ; } ?>>Montserrat</option>
<option value="Morocco"<?php if ($icountry1=="Morocco") { print  selected ; } ?>>Morocco</option>
<option value="Mozambique"<?php if ($icountry1=="Mozambique") { print  selected ; } ?>>Mozambique</option>
<option value="Myanmar"<?php if ($icountry1=="Myanmar") { print  selected ; } ?>>Myanmar</option>
<option value="Namibia"<?php if ($icountry1=="Namibia") { print  selected ; } ?>>Namibia</option>
<option value="Nauru"<?php if ($icountry1=="Nauru") { print  selected ; } ?>>Nauru</option>
<option value="Nepal"<?php if ($icountry1=="Nepal") { print  selected ; } ?>>Nepal</option>
<option value="Netherlands"<?php if ($icountry1=="Netherlands") { print  selected ; } ?>>Netherlands</option>
<option value="Netherlands Antilles"<?php if ($icountry1=="Netherlands Antilles") { print  selected ; } ?>>Netherlands Antilles</option>
<option value="New Caledonia"<?php if ($icountry1=="New Caledonia") { print  selected ; } ?>>New Caledonia</option>
<option value="New Zealand"<?php if ($icountry1=="New Zealand") { print  selected ; } ?>>New Zealand</option>
<option value="Nicaragua"<?php if ($icountry1=="Nicaragua") { print  selected ; } ?>>Nicaragua</option>
<option value="Niger"<?php if ($icountry1=="Niger") { print  selected ; } ?>>Niger</option>
<option value="Nigeria"<?php if ($icountry1=="Nigeria") { print  selected ; } ?>>Nigeria</option>
<option value="Niue"<?php if ($icountry1=="Niue") { print  selected ; } ?>>Niue</option>
<option value="Norfolk Island"<?php if ($icountry1=="Norfolk Island") { print  selected ; } ?>>Norfolk Island</option>
<option value="Northern Mariana Islands"<?php if ($icountry1=="Northern Mariana Islands") { print  selected ; } ?>>Northern Mariana Islands</option>
<option value="Norway"<?php if ($icountry1=="Norway") { print  selected ; } ?>>Norway</option>
<option value="Oman"<?php if ($icountry1=="Oman") { print  selected ; } ?>>Oman</option>
<option value="Pakistan"<?php if ($icountry1=="Pakistan") { print  selected ; } ?>>Pakistan</option>
<option value="Palau"<?php if ($icountry1=="Palau") { print  selected ; } ?>>Palau</option>
<option value="Palestinian Territory, Occupied"<?php if ($icountry1=="Palestinian Territory, Occupied") { print  selected ; } ?>>Palestinian Territory, Occupied</option>
<option value="Panama"<?php if ($icountry1=="Panama") { print  selected ; } ?>>Panama</option>
<option value="Papua New Guinea"<?php if ($icountry1=="Papua New Guinea") { print  selected ; } ?>>Papua New Guinea</option>
<option value="Paraguay"<?php if ($icountry1=="Paraguay") { print  selected ; } ?>>Paraguay</option>
<option value="Peru"<?php if ($icountry1=="Peru") { print  selected ; } ?>>Peru</option>
<option value="Philippines"<?php if ($icountry1=="Philippines") { print  selected ; } ?>>Philippines</option>
<option value="Poland"<?php if ($icountry1=="Poland") { print  selected ; } ?>>Poland</option>
<option value="Portugal"<?php if ($icountry1=="Portugal") { print  selected ; } ?>>Portugal</option>
<option value="Puerto Rico"<?php if ($icountry1=="Puerto Rico") { print  selected ; } ?>>Puerto Rico</option>
<option value="Qatar"<?php if ($icountry1=="Qatar") { print  selected ; } ?>>Qatar</option>
<option value="Reunion"<?php if ($icountry1=="Reunion") { print  selected ; } ?>>Reunion</option>
<option value="Romania"<?php if ($icountry1=="Romania") { print  selected ; } ?>>Romania</option>
<option value="Russian Federation"<?php if ($icountry1=="Russian Federation") { print  selected ; } ?>>Russian Federation</option>
<option value="Rwanda"<?php if ($icountry1=="Rwanda") { print  selected ; } ?>>Rwanda</option>
<option value="Saint Helena"<?php if ($icountry1=="Saint Helena") { print  selected ; } ?>>Saint Helena</option>
<option value="Saint Kitts and Nevis"<?php if ($icountry1=="Saint Kitts and Nevis") { print  selected ; } ?>>Saint Kitts and Nevis</option>
<option value="Saint Lucia"<?php if ($icountry1=="Saint Lucia") { print  selected ; } ?>>Saint Lucia</option>
<option value="Saint Martin"<?php if ($icountry1=="Saint Martin") { print  selected ; } ?>>Saint Martin</option>
<option value="Saint Pierre and Miquelon"<?php if ($icountry1=="Saint Pierre and Miquelon") { print  selected ; } ?>>Saint Pierre and Miquelon</option>
<option value="Saint Vincent and the Grenadines"<?php if ($icountry1=="Saint Vincent and the Grenadines") { print  selected ; } ?>>Saint Vincent and the Grenadines</option>
<option value="Samoa"<?php if ($icountry1=="Samoa") { print  selected ; } ?>>Samoa</option>
<option value="San Marino"<?php if ($icountry1=="San Marino") { print  selected ; } ?>>San Marino</option>
<option value="Sao Tome and Principe"<?php if ($icountry1=="Sao Tome and Principe") { print  selected ; } ?>>Sao Tome and Principe</option>
<option value="Satellite Provider"<?php if ($icountry1=="Satellite Provider") { print  selected ; } ?>>Satellite Provider</option>
<option value="Saudi Arabia"<?php if ($icountry1=="Saudi Arabia") { print  selected ; } ?>>Saudi Arabia</option>
<option value="Senegal"<?php if ($icountry1=="Senegal") { print  selected ; } ?>>Senegal</option>
<option value="Serbia"<?php if ($icountry1=="Serbia") { print  selected ; } ?>>Serbia</option>
<option value="Seychelles"<?php if ($icountry1=="Seychelles") { print  selected ; } ?>>Seychelles</option>
<option value="Sierra Leone"<?php if ($icountry1=="Sierra Leone") { print  selected ; } ?>>Sierra Leone</option>
<option value="Singapore"<?php if ($icountry1=="Singapore") { print  selected ; } ?>>Singapore</option>
<option value="Slovakia"<?php if ($icountry1=="Slovakia") { print  selected ; } ?>>Slovakia</option>
<option value="Slovenia"<?php if ($icountry1=="Slovenia") { print  selected ; } ?>>Slovenia</option>
<option value="Solomon Islands"<?php if ($icountry1=="Solomon Islands") { print  selected ; } ?>>Solomon Islands</option>
<option value="Somalia"<?php if ($icountry1=="Somalia") { print  selected ; } ?>>Somalia</option>
<option value="South Africa"<?php if ($icountry1=="South Africa") { print  selected ; } ?>>South Africa</option>
<option value="Spain"<?php if ($icountry1=="Spain") { print  selected ; } ?>>Spain</option>
<option value="Sri Lanka"<?php if ($icountry1=="Sri Lanka") { print  selected ; } ?>>Sri Lanka</option>
<option value="Sudan"<?php if ($icountry1=="Sudan") { print  selected ; } ?>>Sudan</option>
<option value="Suriname"<?php if ($icountry1=="Suriname") { print  selected ; } ?>>Suriname</option>
<option value="Svalbard and Jan Mayen"<?php if ($icountry1=="Svalbard and Jan Mayen") { print  selected ; } ?>>Svalbard and Jan Mayen</option>
<option value="Swaziland"<?php if ($icountry1=="Swaziland") { print  selected ; } ?>>Swaziland</option>
<option value="Sweden"<?php if ($icountry1=="Sweden") { print  selected ; } ?>>Sweden</option>
<option value="Switzerland"<?php if ($icountry1=="Switzerland") { print  selected ; } ?>>Switzerland</option>
<option value="Syrian Arab Republic"<?php if ($icountry1=="Syrian Arab Republic") { print  selected ; } ?>>Syrian Arab Republic</option>
<option value="Taiwan"<?php if ($icountry1=="Taiwan") { print  selected ; } ?>>Taiwan</option>
<option value="Tajikistan"<?php if ($icountry1=="Tajikistan") { print  selected ; } ?>>Tajikistan</option>
<option value="Tanzania, United Republic of"<?php if ($icountry1=="Tanzania, United Republic of") { print  selected ; } ?>>Tanzania, United Republic of</option>
<option value="Thailand"<?php if ($icountry1=="Thailand") { print  selected ; } ?>>Thailand</option>
<option value="Timor-Leste"<?php if ($icountry1=="Timor-Leste") { print  selected ; } ?>>Timor-Leste</option>
<option value="Togo"<?php if ($icountry1=="Togo") { print  selected ; } ?>>Togo</option>
<option value="Tokelau"<?php if ($icountry1=="Tokelau") { print  selected ; } ?>>Tokelau</option>
<option value="Tonga"<?php if ($icountry1=="Tonga") { print  selected ; } ?>>Tonga</option>
<option value="Trinidad and Tobago"<?php if ($icountry1=="Trinidad and Tobago") { print  selected ; } ?>>Trinidad and Tobago</option>
<option value="Tunisia"<?php if ($icountry1=="Tunisia") { print  selected ; } ?>>Tunisia</option>
<option value="Turkey"<?php if ($icountry1=="Turkey") { print  selected ; } ?>>Turkey</option>
<option value="Turkmenistan"<?php if ($icountry1=="Turkmenistan") { print  selected ; } ?>>Turkmenistan</option>
<option value="Turks and Caicos Islands"<?php if ($icountry1=="Turks and Caicos Islands") { print  selected ; } ?>>Turks and Caicos Islands</option>
<option value="Tuvalu"<?php if ($icountry1=="Tuvalu") { print  selected ; } ?>>Tuvalu</option>
<option value="Uganda"<?php if ($icountry1=="Uganda") { print  selected ; } ?>>Uganda</option>
<option value="Ukraine"<?php if ($icountry1=="Ukraine") { print  selected ; } ?>>Ukraine</option>
<option value="United Arab Emirates"<?php if ($icountry1=="United Arab Emirates") { print  selected ; } ?>>United Arab Emirates</option>
<option value="United Kingdom"<?php if ($icountry1=="United Kingdom") { print  selected ; } ?>>United Kingdom</option>
<option value="United States"<?php if ($icountry1=="United States") { print  selected ; } ?>>United States</option>
<option value="United States Minor Outlying Islands"<?php if ($icountry1=="United States Minor Outlying Islands") { print  selected ; } ?>>United States Minor Outlying Islands</option>
<option value="Uruguay"<?php if ($icountry1=="Uruguay") { print  selected ; } ?>>Uruguay</option>
<option value="Uzbekistan"<?php if ($icountry1=="Uzbekistan") { print  selected ; } ?>>Uzbekistan</option>
<option value="Vanuatu"<?php if ($icountry1=="Vanuatu") { print  selected ; } ?>>Vanuatu</option>
<option value="Venezuela"<?php if ($icountry1=="Venezuela") { print  selected ; } ?>>Venezuela</option>
<option value="Vietnam"<?php if ($icountry1=="Vietnam") { print  selected ; } ?>>Vietnam</option>
<option value="Virgin Islands, British"<?php if ($icountry1=="Virgin Islands, British") { print  selected ; } ?>>Virgin Islands, British</option>
<option value="Virgin Islands, U.S."<?php if ($icountry1=="Virgin Islands, U.S.") { print  selected ; } ?>>Virgin Islands, U.S.</option>
<option value="Wallis and Futuna"<?php if ($icountry1=="Wallis and Futuna") { print  selected ; } ?>>Wallis and Futuna</option>
<option value="Yemen"<?php if ($icountry1=="Yemen") { print  selected ; } ?>>Yemen</option>
<option value="Zambia"<?php if ($icountry1=="Zambia") { print  selected ; } ?>>Zambia</option>
<option value="Zimbabwe"<?php if ($icountry1=="Zimbabwe") { print  selected ; } ?>>Zimbabwe</option>
</select>
      </td>
    </tr>
<?php                                                   
if (isset($countrymessage)) { Print "
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>".$countrymessage."</td>
    </tr>";
}
?>
    <tr>
      <td><?php echo "$Email"; ?></td>
      <td>&nbsp;</td>
      <td><input name="email1" type="text" class="input1" value='<?php echo "$iemail1"; ?>' size="70" maxlength="70" /></td>
    </tr>
<?php                                                   
if (isset($emailmessage)) { Print "
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>".$emailmessage."</td>
    </tr>";
}
?>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
  <br />
<table width="610" border="0" align="center" cellpadding="0">
  <tr>
  <td width="215">&nbsp;</td>
  <td width="182"><input name="submit" type="submit" value='<?php echo "$Save_Account"; ?>' /></td>
  <td width="205"></td>
  </tr>
  </table>
</form>
                      
<form name="form02" method="post" action="../index.php?in=login8">
    <input type="hidden" name="data" value="<?php echo @$adata ?>">
<table width="610" border="0" align="center" cellpadding="0">
   <tr>
    <td width="190">&nbsp;</td>
    <td width="22">&nbsp;</td>
    <td width="387" align="right"><input type="submit" value='<?php echo "Back to Domainlist"; ?>' /></td>
    </tr>
</table>
</form>
</center>
