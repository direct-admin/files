<br>
<table width="100%" border="0" cellpadding="0" cellspacing="0" id="Table_02">
<tr><td valign="top" class="style11">
<div align="center">
<p><a href="index.php" rel="nofollow"><?php echo "$bot_Home"; ?></a></p>
<p class="style3">
<table width="664"  border="0">
<tr><td width="658" class="style10b">
<br>
WHAT IS <?php echo "$maindomain2ext"; ?><?php echo "$maindomainext"; ?>?</td>
</tr><tr><td class="style10">
<br>
We are a free domain name registration service.
You can register up to 5 domain names for free.
Use the search box above to find a subdomain name is available at our free domain name registration.
<br><br>
You can register all available domain names instantly.
<br><br>
<?php echo "$bot_Register_a_free_domain_now"; ?>
<br />
</td></tr></table>
<br><br>
<center>
<span class="style8c"><?php echo "$maindomain2ext"; ?></span><span class="style8d"><?php echo "$maindomainext"; ?></span>
<br><br>
<span class="style15">All Rights Reserved - Copyright 2013 by 14dragons.com</span>
<br><br><br><br></center>
</div></div></div>
</td></tr></table>
</body>
</html>

