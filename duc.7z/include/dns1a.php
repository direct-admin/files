<?php
if(define("liteB105", false)) die("Hacking System");

#######################

		$adata = "";
		$tekens1 = array_merge(range('A', 'Z'), range(0, 9));
		for ($i1 = 0; $i1 < 8; $i1++) { $adata .= $tekens1[rand(0, count($tekens1) - 1)]; }
		$auserid1 = $iuserid;
		$adomainid1 = $idomainid;
		$adate1 = date("dmy");

		$sql1 = "INSERT INTO data1 ( data, userid, domainid, date) VALUES ('$adata', $auserid1, $adomainid1, '$adate1')";
		mysql_query($sql1) or die ("no. 1 Couldn't execute query : " . mysql_error());				

#######################

		 $csv_output = "<br><center><font size='4'>".$dlist_Zone_Records_Setup_NS_A_CNAME_MX_SOA_AAAA."</font><br><br>
						<center><font size='3'>".$dlist_setting_up_Zone_Records_your_domain." <b>".$isubdomainname2."</b>		
						</font></center><br>
						<center><font size='3'><b>".$dlist_Your_current_Zone_Records."</b></font></center>
						<BR>
						<table align='center' border='0' cellpadding='4' cellspacing='0'>
						<tr><td align='left' bgcolor='#000000'>
						<font size='2' color='#FFFFFF'><b>".$dlist_Host."</b></font>
						</td><td bgcolor='#000000'>
						<font size='2' color='#FFFFFF'><b><center>".$dlist_TTL."</center></b></font>
						</td><td bgcolor='#000000'>
						<font size='2' color='#FFFFFF'><b><center>".$dlist_type."</center></b></font>						
						</td><td bgcolor='#000000'>
						<font size='2' color='#FFFFFF'><b><center>".$dlist_data."</center></b></font>
						</td><td bgcolor='#000000'>
						<font size='2' color='#FFFFFF'><b><center>".$dlist_Prio."</center></b></font>
						</td><td bgcolor='#000000'>
						<font size='2' color='#FFFFFF'><b><center>".$dlist_Date."</center></b></font>
						</td><td bgcolor='#000000'>
						<font size='2' color='#FFFFFF'><b><center>".$dlist_Delete."</center></b></font>
						</td></tr>";
						
				$sql211 = "SELECT * FROM powerdnsdata1.records WHERE domain_id='$powerdns_domain_id1' AND domainid='$idomainid'";       
      						$result211 = mysql_query($sql211) or die ("Couldn't execute query : " . mysql_error());      
							$num211 = mysql_num_rows($result211);                     
						if ($num211 > 0)  // dns records
						{

						while ($row211 = mysql_fetch_array($result211))
						{
				
				$Cdate6 = date("d-m-Y H:i", $row211[change_date]);

		$csv_output .= "<tr><td align='left'>
						<font size='3'>" .$row211[name]."</font>
						</td><td align='center'>
						<font size='3'>" .$row211[ttl]. "</font>
						</td><td align='center'>
						<font size='3'>" .$row211[type]. "</font>
						</td><td align='center'>
						<font size='3'>" .$row211[content]. "</font>
						</td><td align='center'>
						<font size='3'>" .$row211[prio]. "</font>";
		$csv_output .= "</td><td align='center'>
						<font size='3'>" .$Cdate6. "</font>
						</td><td align='center'>
						<a href='index.php?in=delete9&data=".$adata."&domainrecordid=".$row211[id]."'>
						<img src='images/delete.png' alt='Delete record' border=0></a>
						</td></tr>";

		 				}

		    			$csv_output .= "
						</table>" ;

		  				print $csv_output;
						print "<br><br><br><br>".$message;
						
						} else {
						
						$csv_output .= "
						</table>
						<br>
						no records" ;
						
		  				print $csv_output;
						print "<br><br><br><br>".$message;
						
						}


$csv_output3 = "<br><br>
  <center>
<a href='index.php?in=login9&data=".$adata."'><font size='5'><b>".$dlist_back_to_domainlist."</b></font></a>
<br>
<br>".$dlist_Important."<br></center>" ;

print $csv_output3 ;

?>