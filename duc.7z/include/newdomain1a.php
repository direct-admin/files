<link href="../css/style.css" rel="stylesheet" type="text/css">
<?php
if(define("liteB105", false)) die("Hacking System");

#######################

		$adata = "";
		$tekens1 = array_merge(range('A', 'Z'), range(0, 9));
		for ($i1 = 0; $i1 < 8; $i1++) { $adata .= $tekens1[rand(0, count($tekens1) - 1)]; }
		$auserid1 = $iuserid;
		$adomainid1 = 0;
		$adate1 = date("dmy");

		$sql1 = "INSERT INTO data1 ( data, userid, domainid, date) VALUES ('$adata', $auserid1, $adomainid1, '$adate1')";
		mysql_query($sql1) or die ("no. 1 Couldn't execute query : " . mysql_error());				

#######################

?>
</center>
    <br />
    <form name="form01" method="post" action="../index.php?in=newdomain2">
    <input type="hidden" name="data" value="<?php echo @$adata ?>">
<table border="0" align="center">
    <tr>
      <td >&nbsp;</td>
      <td colspan="2" class="text2"><?php echo "$nd_Registrate_a_new_domain"; ?></td>
    </tr>
    <tr>
      <td >&nbsp;</td>
      <td >&nbsp;</td>
      <td >&nbsp;</td>
    </tr>
    <tr>
      <td >&nbsp;</td>
      <td >&nbsp;</td>
      <td >&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><?php echo "$nd_Enter_the_domainname_your_want_to_registrate"; ?></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td >&nbsp;</td>
      <td >&nbsp;</td>
      <td >&nbsp;</td>
    </tr>  
    <tr>
      <td align="right"><span class="style3">www.&nbsp;</span></td>
      <td align="left"><input name="newdomainname1" type="text" class="style4" size="35" maxlength="60" /></td>
      <td align="left"><span class="style3">&nbsp;.<?php echo "$maindomain"; ?></span></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="left"><span class="style7"><?php echo "$example_www_yourname"; ?><?php echo "$maindomain"; ?></span></td>
      <td>&nbsp;</td>
    </tr>
  
<?php                                                   
if (isset($newdomainname1message)) { Print "
    <tr>
      <td>&nbsp;</td>
      <td colspan=2>".$newdomainname1message."</td>
    </tr> "; }
?>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
  <br />
<table width="610" border="0" align="center" cellpadding="0">
  <tr>
  <td width="215">&nbsp;</td>
  <td width="182"><input name="submit" type="submit" value='<?php echo "$nd_Registrate_new_domain"; ?>' /></td>
  <td width="205"></td>
  </tr>
  </table>
</form>                    
<form name="form02" method="post" action="../index.php?in=login9&lng=<?php echo $lng1; ?>">
    <input type="hidden" name="data" value="<?php echo @$adata ?>">
<table width="610" border="0" align="center" cellpadding="0">
   <tr>
    <td width="190">&nbsp;</td>
    <td width="22">&nbsp;</td>
    <td width="387" align="right"><input type="submit" value='<?php echo "Back to Domainlist"; ?>' /></td>
    </tr>
</table>
</form>
</center>