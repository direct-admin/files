<?php
if(define("liteB105", false)) die("Hacking System");

#######################

		$adata = "";
		$tekens1 = array_merge(range('A', 'Z'), range(0, 9));
		for ($i1 = 0; $i1 < 8; $i1++) { $adata .= $tekens1[rand(0, count($tekens1) - 1)]; }
		$auserid1 = $iuserid;
		$adomainid1 = $idomainid;
		$adate1 = date("dmy");

		$sql1 = "INSERT INTO data1 ( data, userid, domainid, date) VALUES ('$adata', $auserid1, $adomainid1, '$adate1')";
		mysql_query($sql1) or die ("no. 1 Couldn't execute query : " . mysql_error());				

#######################

?>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<style type="text/css">
input.buttonskinA{
	color:#5e2708;
	background:bottom;
	border-top:1px solid #f39d24;
	border-left:1px solid #f39d24;
	border-right:1px solid #cf6f18;
	border-bottom:1px solid #cf6f18;
	background-color: #feeeb1;
	background-repeat: repeat-x;
}
</style>
</center>
<br />
<center>
<form name="form01" method="post" action="../index.php?in=registersave7">
<input type="hidden" name="data" value="<?php echo @$adata ?>">
<table width="950" border="0" cellpadding="1" cellspacing="1">
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><?php echo "$Domeinname"; ?>&nbsp;</td>
    <td align="left"><span class="style3"><?php echo "$isubdomainname1"; ?>.<?php echo "$idomainname1"; ?></span></td>
    <td>&nbsp;</td>
  </tr>
   <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
   </tr>
   <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><label><input name="service" type="radio" value="noservice"<?php if ($iservice1=="noservice" or $iservice1=="") { print ' checked="checked"'  ; } ?> />1. <?php echo "$No_Settings"; ?></label></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
<?php                                                   
if (isset($nameserver1message)) { Print "
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>".$nameserver1message."</td>
    </tr> "; }
?>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
    <label><input name="service" type="radio" value="nameservers"<?php if ($iservice1=="nameservers") { print ' checked="checked"'  ; } ?> />2. <?php echo "$Name_Servers"; ?></label>
    </td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    </tr>
  <tr>
    <td>&nbsp;</td>
    <td><?php echo "$Name_Server_1"; ?></td>
    <td><input name="nameserver1" type="text" value='<?php echo "$inameserver11"; ?>' size="50" /></td>
    <td>&nbsp;</td>
    </tr>
<?php                                                   
if (isset($nameserver1message)) { Print "
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>".$nameserver1message."</td>
    </tr> "; }
?>
  <tr>
    <td>&nbsp;</td>
    <td><?php echo "$Name_Server_2"; ?></td>
    <td><input name="nameserver2" type="text" value='<?php echo "$inameserver21"; ?>' size="50" /></td>
    <td>&nbsp;</td>
    </tr>
<?php                                                   
if (isset($nameserver2message)) { Print "
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>".$nameserver2message."</td>
    </tr> "; }
?>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
      <label><input type="radio" name="service" value="zonerecords"<?php if ($iservice1=="zonerecords") { print ' checked="checked"'  ; } ?> />3. <?php echo "$Zone_Record"; ?></label></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><?php echo "$IPv4_address"; ?></td>
    <td><input name="ipaddress" type="text" size="50" value='<?php echo "$iipaddress1"; ?>' /></td>
    <td>&nbsp;</td>
    </tr>
<?php                                                   
if (isset($ipaddressmessage)) { Print "
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>".$ipaddressmessage."</td>
    </tr> "; }
?>
  <tr>
    <td>&nbsp;</td>
    <td><?php echo "$IPv6_address"; ?></td>
    <td><input name="ipaddress2" type="text" size="50" value='<?php echo "$iipaddress2"; ?>' /></td>
    <td>&nbsp;</td>
    </tr>
<?php                                                   
if (isset($ipaddressmessage2)) { Print "
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>".$ipaddressmessage2."</td>
    </tr> "; }
?>  
   <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    </tr>   
  <tr>
    <td>
    <label><input name="service" type="radio" value="forwarding"<?php if ($iservice1=="forwarding") { print ' checked="checked"' ; } ?> />4. <?php echo "$URL_Forwarding"; ?></label>
    </td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    </tr>
  <tr>
    <td>&nbsp;</td>
    <td><?php echo "$Redirect_To_URL"; ?> </td>
    <td><input name="url" type="text" size="44" value='<?php echo "$iurl1"; ?>' /></td>
    <td>&nbsp;</td>
    </tr>
<?php                                                   
if (isset($urlmessage1)) { Print "
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>".$urlmessage1."</td>
    </tr> "; }
?>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><font size=-4><?php echo "$Include_HTTP"; ?></font>
    </td>
    <td>&nbsp;</td>
    </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><label><input name="service" type="radio" value="googleservice"<?php if ($iservice1=="googleservice") { print ' checked="checked"' ; } ?> />5. Google Apps</label></td>
    <td> TXT-record :</td>
    <td><input name="googletxt" type="text" size="70" value='<?php echo "$igoogletxt1"; ?>' /></td>
    <td><a href="http://www.google.com/apps/intl/en/group/index.html" target="_new"><font size=-1>Google Apps</font></a></td>
    </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><font size=-2>google-site-verification=ABCDEFG_ABCDEFGHIMNOP-ABCDEFGHIJKLMNOPQRSTU</font></td>
    <td>&nbsp;</td>
    </tr>
<?php                                                   
if (isset($googlemessage)) { Print "
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>".$googlemessage."</td>
    </tr> "; }
?>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><label><input name="service" type="radio" value="microsoftlive"<?php if ($iservice1=="microsoftlive") { print ' checked="checked"' ; } ?> />6. Microsoft Live</label></td>
    <td>MX-server :</td>
    <td><input name="microsoftmx" type="text" size="50" value='<?php echo "$imicrosoftmx1"; ?>' /></td>
    <td><a href="http://domains.live.com" target="_new"><font size=-1>MS Custom Domain</font></a></td>
    </tr>
  <tr>
    <td><div align="right"><font size=-2>(Custom Domains)</font></div></td>
    <td>&nbsp;</td>
    <td><font size=-2>1234567890123456789.pamx1.hotmail.com</font></td>
    <td>&nbsp;</td>
    </tr>
<?php                                                   
if (isset($microsoftmessage)) { Print "
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>".$microsoftmessage."</td>
    </tr> "; }
?>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input name="submit" type="submit" value='<?php echo "$Registar_Save"; ?>' /></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  </table>
</form>

<form action="../index.php?in=login57" method="post" target="_self">
<input type="hidden" name="data" value="<?php echo @$adata ?>">
<table width="642" border="0" align="center" cellpadding="0">
   <tr>
    <td width="163">&nbsp;</td>
    <td width="139">&nbsp;</td>
    <td width="332" align="right"><input type="submit" value='<?php echo "$Back"; ?>' /></td>
    </tr>
</table>
</form>
</center>