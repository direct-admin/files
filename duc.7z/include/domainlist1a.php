<?php
if(define("liteB105", false)) die("Hacking System");

#######################

		$edata = "";
		$tekens1 = array_merge(range('A', 'Z'), range(0, 9));
		for ($i1 = 0; $i1 < 8; $i1++) { $edata .= $tekens1[rand(0, count($tekens1) - 1)]; }
		$euserid1 = $iuserid;
		$edomainid1 = 0;
		$edate1 = date("dmy");

		$sql1 = "INSERT INTO data1 ( data, userid, domainid, date) VALUES ('$edata', $euserid1, $edomainid1, '$edate1')";
		mysql_query($sql1) or die ("no. 1 Couldn't execute query : " . mysql_error());				

#######################

		$sql2 = "SELECT maxdomains1 FROM users WHERE id='$iuserid'"; 
    	$result2 = mysql_query($sql2) or die ("Couldn't execute query : " . mysql_error());   		 
			while ($row2 = mysql_fetch_array($result2))
			{
				extract($row2);
				$maxdomains1 = $maxdomains1;
			}
					
		$sql = "SELECT * FROM domains WHERE userid=$iuserid";       
      	$result = mysql_query($sql) or die ("Couldn't execute query : " . mysql_error());;      
		$num = mysql_num_rows($result);                     
		if ($num > 0)  // domain's
		{
			$csv_output = "<center>
			<img src='images/newdomain.gif' alt='New Domain' border=0>&nbsp;&nbsp;&nbsp;
			<a href='index.php?in=newdomain1&data=".$edata."'>
			<font size='4'>".$dlist_New_Domain."</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						
			<img src='images/profile.gif' alt='Profile' border=0>&nbsp;&nbsp;&nbsp;
			<a href='index.php?in=profile1&data=".$edata."'>
			<font size='4'>".$dlist_My_Profile."</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					
			<img src='images/password.gif' alt='Password' border=0>&nbsp;&nbsp;&nbsp;
			<a href='index.php?in=passwordchange1&data=".$edata."'>
			<font size='4'>".$dlist_My_Password."</font></a>
						
			<BR><BR><BR>
						
			<font size='5'>".$dlist_My_Domains."</font></center>
			<table align='center' border='0' cellpadding='4' cellspacing='0'>
			<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td colspan=4>You may register max. of ".$maxdomains1." free subdomains.</td></tr>
						
			<tr><td align='left' bgcolor='#000000'>
			<font size='2' color='#FFFFFF'><b>&nbsp;".$dlist_Domain."&nbsp;&nbsp;</b></font>
			</td><td align='left' bgcolor='#000000'>
			<font size='2' color='#FFFFFF'><b><center>".$dlist_Settings."</center></b></font>						
			</td><td bgcolor='#000000'>
			<font size='2' color='#FFFFFF'><b><center>".$dlist_DNS."</center></b></font>						
			</td><td bgcolor='#000000'>
			<font size='2' color='#FFFFFF'><b><center>".$dlist_Lock."</center></b></font>
			</td><td bgcolor='#000000'>
			<font size='2' color='#FFFFFF'><b><center>".$dlist_Delete."</center></b></font>
			</td><td bgcolor='#000000'>
			<font size='1' color='#FFFFFF'><center>".$dlist_Created."</center></font>
			</td></tr>";

			while ($row = mysql_fetch_array($result))
			{
						
			$cdate2 = date("dmy");

#######################

		$fdata = "";
		$tekens2 = array_merge(range('A', 'Z'), range(0, 9));
		for ($i2 = 0; $i2 < 8; $i2++) { $fdata .= $tekens2[rand(0, count($tekens2) - 1)]; }
		$fuserid1 = $row[userid];
		$fdomainid1 = $row[id];
		$fdate1 = date("dmy");

		$sql2 = "INSERT INTO data1 ( data, userid, domainid, date) VALUES ('$fdata', $fuserid1, $fdomainid1, '$fdate1')";
		mysql_query($sql2) or die ("no. 2 Couldn't execute query : " . mysql_error());				

#######################

			$subdomain1 = $row[subdomainname1].".".$row[domainname1];
						
			$Cdate5 = $row[date1];
			$Ctime5 = $row[time1];
			$Dtime5 = $row[expires];					
						
	$csv_output .= "<tr><td align='left'>
					<font size='3'>&nbsp;" .$subdomain1."&nbsp;&nbsp;&nbsp;&nbsp;</font>
					</td><td align='center'>";


	$csv_output .= "<a href='index.php?in=settings1&data=".$fdata."'>
					<img src='images/manage.png' alt='Setting this Domain' border=0></a>"; 


	$csv_output .= "</td><td align='center'>";
	$csv_output .= "<a href='index.php?in=dnsmanage1&data=".$fdata."'>
					<img src='images/manage.png' alt='Manage this Domain' border=0></a>"; 
	$csv_output .= "</td><td align='center'>";
	$csv_output .= "<a href='index.php?in=domainlock&data=".$fdata."'>";
	if ($row[domainlock1] == 0){
		$csv_output .= "<img src='images/no.png' alt='Add Domain Lock' border=0></a>";}
	if ($row[domainlock1] >= 1){
		$csv_output .= "<img src='images/yes.png' alt='Remove Domain Lock' border=0></a>";}
	$csv_output .= "</td><td align='center'>";
	$csv_output .= "<a href='index.php?in=delete&data=".$fdata."'>
						<img src='images/delete.png' alt='Delete this domain' border=0></a>"; 								
	$csv_output .= "</td><td align='center'><font size='3'>&nbsp;" .$Cdate5. "&nbsp;&nbsp;</font></td></tr>";
}
	$csv_output .= "</table>";
	$csv_output .= "<br><br><br><center>".$message."</center><br><br>
					<p class='style14'>
					<a href='index.php?in=logout&data=".$edata."'>".		
					$dlist_Logout."</a></p><br>" ;

print $csv_output;
				
} else {
	
	$csv_output = "<center>
					<img src='images/newdomain.gif' alt='New Domain' border=0>&nbsp;&nbsp;&nbsp;
					<a href='index.php?in=newdomain1&data=".$edata."'>
					<font size='4'>".$dlist_New_Domain."</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						
					<img src='images/profile.gif' alt='Profile' border=0>&nbsp;&nbsp;&nbsp;
					<a href='index.php?in=profile1&data=".$edata."'>
					<font size='4'>".$dlist_My_Profile."</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						
					<img src='images/password.gif' alt='Password' border=0>&nbsp;&nbsp;&nbsp;
				<a href='index.php?in=passwordchange1&data=".$edata."'>
					<font size='4'>".$dlist_My_Password."</font></a>
						
					<BR><BR><BR>
					
					<font size='5'>".$dlist_My_Domains."</font></center>
					<table align='center' border='0' cellpadding='4' cellspacing='0'>
					<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td colspan=4>You may register max. of ".$maxdomains1." domains.</td></tr>
					<tr>
					<td align='left' bgcolor='#000000'>
					<font size='2' color='#FFFFFF'><b>&nbsp;".$dlist_Domain."&nbsp;&nbsp;</b></font>
					</td><td bgcolor='#000000'>
					<font size='2' color='#FFFFFF'><b><center>".$dlist_Settings."</center></b></font>						
					</td><td bgcolor='#000000'>
					<font size='2' color='#FFFFFF'><b><center>".$dlist_DNS."</center></b></font>						
					</td><td bgcolor='#000000'>
					<font size='2' color='#FFFFFF'><b><center>".$dlist_Lock."</center></b></font>
					</td><td bgcolor='#000000'>
					<font size='2' color='#FFFFFF'><b><center>".$dlist_Delete."</center></b></font>
					</td><td bgcolor='#000000'>
					<font size='1' color='#FFFFFF'><center>".$dlist_Created."</center></font>
					</td></tr></table>
					<center><BR><BR>					
					<font size='5'>".$dlist_You_dont_have_any_domains_yet."</font>
					<BR></center>";
					
	$csv_output .= "<br><br><br><center>".$message."</center><br><br><p class='style14'> 
					<a href='index.php?in=logout&data=".$edata."'>".
					$dlist_Logout."</a></p><br>" ;

print $csv_output;
}
?>