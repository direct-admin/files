<?php
if(define("liteB105", false)) die("Hacking System");

$connection = mysql_connect($mysql_host1,$mysql_username1,$mysql_passwd1) 
		or die ('Could not connect : ' . mysql_error());
$db = mysql_select_db($mysql_dbase1,$connection)
		or die ("Can\'t use database : " . mysql_error()); 
 	
$result = mysql_query("SELECT * FROM options WHERE id=1");
$row = mysql_fetch_array($result);

$pagetitle = $row[sitetitle];

$adminmail = $row[adminemail];
$noreplyemail = $row[noreplyemail];

$maindomain = $row[maindomain];
$maindomain2ext = $row[maindomain2ext]; 
$maindomainext = $row[maindomainext];

$configmaxdomains1 = $row[configmaxdomains];

$minlength = $row[minlength];
$maxlength = $row[maxlength];

$dnssoa1 = $row[dnssoa1];
$dnssoa2 = $row[dnssoa2];
?>