<?php
if(define("liteB105", false)) die("Hacking System");

	$iusername = strtolower($_REQUEST["username1"]);
	$ipassword1 = $_REQUEST["password1"];
	$ipassword2 = $_REQUEST["password2"];
	$ifullname1 = $_REQUEST["fullname1"];
	$istreetnumber1 = $_REQUEST["streetnumber1"];		
	$ipostcode1 = $_REQUEST["postcode1"];
	$icity1 = $_REQUEST["city1"];
	$icountry1 = $_REQUEST["country1"];
	$iemail1 = strtolower($_REQUEST["email1"]);	
	
	$hash_password = create_hash($ipassword1);

	$outputmsg1 = check_usernamenew($iusername);

	if ($outputmsg1){
		$usernamemessage = $outputmsg1 ;
		include("include/website1b.php");	
		include("include/register4a.php");
		include("include/website2.php");
		exit;
	}

	if ($ipassword1 !== $ipassword2) {
		$passwordmessage = '<font color="#FF0000"><b>Password is not eqwol</b></font>';    
		include("include/website1b.php");	
		include("include/register4a.php");
		include("include/website2.php");
		exit;
	}

	if (strlen($ipassword1) < 5) {
		$passwordmessage = '<font color="#FF0000"><b>Sorry, but this password is too short, minimum length is 5.</b></font>';    
		include("include/website1b.php");	
		include("include/register4a.php");
		include("include/website2.php");
		exit;
	}

	if(!$ifullname1 || strlen($ifullname1) > 70) {
		$namemessage = '<font color="#FF0000"><b><center>fullname not valid</center></b></font>';    
		include("include/website1b.php");	
		include("include/register4a.php");
		include("include/website2.php");
		exit;
	}

	$outputmsg1 = verify_email($iemail1);

	if ($outputmsg1){
		$emailmessage = $outputmsg1 ;
		include("include/website1b.php");	
		include("include/register4a.php");
		include("include/website2.php");
		exit;
	}


	if( strtolower($_REQUEST['ct_captcha']) === strtolower($_SESSION['captcha']['code']) ) {
		
	} else {
		$securitymessage = '<font color="#FF0000"><b><center>The code you entered was invalid.</center></b></font>';    
		include("include/website1b.php");	
		include("include/register4a.php");
		include("include/website2.php");
		exit;
	}

	if(ipaddress_check($ipaddress)) {
		$message = "<font color = \"red\">Sorry but there is already an account created with your ipaddress.</font><br>";	  
		include("include/website1b.php");	
		include("include/register4a.php");
		include("include/website2.php");
		exit;
	}

$activationcode1 = '';
$tekens = array_merge(range('A', 'Z'), range(0, 9));
for ($i = 0; $i < 8; $i++) {
    $activationcode1 .= $tekens[rand(0, count($tekens) - 1)];
}
			
		$sql6 = "INSERT INTO users (id,logindate,username1,password1,activationcode1, fullname1,streetnumber1,postcode1,city1,country1,email1,maxdomains1,ipaddress1,createdate1,createtime1,date1,time1) VALUES ('','$itodaydate','$iusername','$hash_password','$activationcode1','$ifullname1','$istreetnumber1','$ipostcode1','$icity1','$icountry1', '$iemail1','$configmaxdomains1','$ipaddress','$itodaydate','$itodaytime','$itodaydate','$itodaytime')";
			
        mysql_query($sql6) or die ("Couldn't execute query : " . mysql_error());

		$sql38 = "SELECT * FROM users WHERE username1='$iusername' and password1='$encrypted_password' and ipaddress1='$ipaddress' and date1='$itodaydate' and time1='$itodaytime' LIMIT 1";       
      	$result38 = mysql_query($sql38) or die ("Couldn't execute query : " . mysql_error()); 
		while ($row38 = mysql_fetch_array($result38))
			{
				extract($row38);
				$iuserid = $id;
			}
		
		$aemailadres1 = $noreplyemail ;
		
		$aemail_from = "from:".$aemailadres1 ;
		$aemail_to = $iemail1;
		$asubject = "Registration activation for user : ".$iusername." on domain : ".$maindomain ;

	$amessage .= "Dear ".$ifullname1.",\n\n";
	$amessage .= "Welcome to ".$maindomain." !\n\n";
	$amessage .= "Below you will find your activation information :\n\n";
	$amessage .= "Login and full in your activation code, after that you can register up to 5 subdomains with this account for free.\n\n";  
	$amessage .= "Activation code : ".$activationcode1."\n\n";
	$amessage .= "Your loginname is : ".$iusername."\n\n";
	$amessage .= "Your password is : ".$ipassword1."\n\n";
	$amessage .= "Once you are logged in, you can manager your domain names to fit your needs.\n\n";
	$amessage .= "This is an automated message.\n";
	$amessage .= "Please do not respond to this e-mail.\n\n";
	$amessage .= "Again, thank you for choosing ".$maindomain." Domain Name Registration Service.\n\n";
	$amessage .= "Best Regards,\n".$maindomain."\n\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
	$amessage .= "IPaddress : \t\t" .$ipaddress."\n";

	if ( mail($aemail_to , $asubject , $amessage , $aemail_from ) ) {
	
	} else {
		$message = '<font color="#FF0000"><b>Error 36 : Mail not working.</b></font>';
		include("include/website1a.php");
		include("include/website2.php");
		exit;
	}
			
	$aemailadres1 = $noreplyemail ;
		
	$aemail_from = "from:". $aemailadres1 ;
	$aemail_to = $adminmail;
	$asubject = "Registration User on domain : ". $maindomain ;

	$amessage = "Registration User on domain ". $maindomain. "\n\n";
	$amessage .= "UsernameID : \t\t" . $iuserid . "\n\n";
	$amessage .= "Username : \t\t" . $iusername . "\n";
	$amessage .= "Password : \t\t" . $encrypted_password . "\n\n";
	$amessage .= "Activation code : \t" . $activationcode1 . "\n\n";
	$amessage .= "Fullname : \t\t" . $ifullname1 . "\n";
	$amessage .= "Street : \t\t" . $istreetnumber1 . "\n";
	$amessage .= "Postcode : \t\t" . $ipostcode1 . "\n";
	$amessage .= "City : \t\t\t" . $icity1 . "\n";
	$amessage .= "Country : \t\t" . $icountry1 . "\n\n";
	$amessage .= "Email : \t\t\t" . $iemail1 . "\n\n";
	$amessage .= "MainDomain : \t\t" . $maindomain . "\n\n";
	$amessage .= "Create Time : \t\t" . $itodaytime . "\n";
	$amessage .= "Create Date : \t\t" . $itodaydate . "\n\n";
	$amessage .= "IPaddress : \t\t" . $ipaddress . "\n";
	$amessage .= "-----------------------------------------------------------------------\n\n";
	$amessage .= "\n\n\n\n";

	if ( mail($aemail_to , $asubject , $amessage , $aemail_from ) ) {
	}
	else
	{
	$message = '<font color="#FF0000"><b>Error 36 : Mail not working.</b></font>';

	include("include/website1a.php");
	include("include/website2.php");
	exit;
	}

	$message = '<font color="#000000"><b>Registration Complete !</b><br>Now you can registrate a domain.</font><br>' ;
	include("include/website1a.php");
	include("include/website2.php");
	exit;
?>