<?php
if(define("liteB105", false)) die("Hacking System");

function check_domain($dname) {
global $minlength, $maxlength;
	if ($dname == ''){
		$errormsg1 = "<font color = \"red\">No domain selected the field is empty.</font><br>";
		return $errormsg1;	
	}
	if(preg_match('/[^a-zA-Z0-9\-]/',$dname)) {
		if(preg_match('/[\$\&\+\,\/\.\:\;\=\?\@\<\>\#\%\{\}\|\\\^\~\[\]\`]/',$dname)) {
			$errormsg1 = "<font color = \"red\">Sorry, but you used one or more of this characters $&+,/.:;=?@<>#%{}|\^~[]`, and they are not allowed.</font><br>";
			return $errormsg1;
		}
	}

	if (strlen($dname) < $minlength || strlen($dname) > $maxlength) {
	$errormsg1 .= "<font color = \"red\">Sorry, but this domain name is too short or too long.<br>Be aware, that minimum length of your domainname is $minlength, and maximum is $maxlength.</font><br>";
	}
	return $errormsg1;
}

function check_ipv4a($ipv4a) {
global $iservice1;
if ($iservice1 == 'zonerecords'){
		if ($ipv4a == ''){
		$errormsg2 = "<font color = \"red\">IP adres field is emptie.</font><br>";
		return $errormsg2;	
		}
	$ipv4b=filter_var($ipv4a, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4);
	if($ipv4b==''){ 
		$errormsg2 = "<font color = \"red\">Sorry, but this is a incorrect ipv4 ipaddress.</font><br>";
		return $errormsg2;
	}
	$ipv4c=filter_var($ipv4a, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE);
	if($ipv4c==''){
		$errormsg2 = "<font color = \"red\">Sorry, but this private range ipv4 ipaddress is not allowed.</font><br>";
		return $errormsg2;
	}
	$ipv4d=filter_var($ipv4a, FILTER_VALIDATE_IP, FILTER_FLAG_NO_RES_RANGE);
	if($ipv4d==''){
		$errormsg2 = "<font color = \"red\">Sorry, but this reserved range ipv4 ipaddress is not allowed.</font><br>";
		return $errormsg2;
	}
	if ($iservice1 == 'zonerecords'){
		if (strlen($ipv4a) < 7 || strlen($ipv4a) > 15) {
		$errormsg2 .= "<font color = \"red\">Sorry, but the ipadress is too short or too long.</font><br>";
		}
	}
	return $errormsg2;
}
}

function check_ipv6a($ipv6a) {
global $iservice1;
if ($iservice1 == 'zonerecords'){
		if ($ipv6a==''){
			$errormsg3 = "<font color = \"red\">IP adres field is emptie.</font><br>";
			return $errormsg3;	
		}
	$ipv6b=filter_var($ipv6a, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6);
	if($ipv6b==''){ 
		$errormsg3 = "<font color = \"red\">Sorry, but this is a incorrect ipv6 ipaddress.</font><br>";
		return $errormsg3;
	}
	$ipv6c=filter_var($ipv6a, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE);
	if($ipv6c==''){
		$errormsg3 = "<font color = \"red\">Sorry, but this private range ipv6 ipaddress is not allowed.</font><br>";
		return $errormsg3;
	}
	$ipv6d=filter_var($ipv6a, FILTER_VALIDATE_IP, FILTER_FLAG_NO_RES_RANGE);
	if($ipv6d==''){
		$errormsg3 = "<font color = \"red\">Sorry, but this reserved range ipv6 ipaddress is not allowed.</font><br>";
		return $errormsg3;
	}
	if (strlen($ipv6a) < 3 || strlen($ipv6a) > 39) {
		$errormsg3 = "<font color = \"red\">Sorry, but the ipadress is too short or too long.</font><br>";
		return $errormsg3;
	}
	return $errormsg3;
}
}

function check_nsa1($nsa1) {
global $iservice1;
	if ($iservice1 == 'nameservers'){
		if ($nsa1 == ''){
			$errormsg41 = "<font color = \"red\">NS record field is emptie.</font><br>";
			return $errormsg41;	
		}
	}
	if(filter_var($nsa1, FILTER_VALIDATE_URL)){
		$errormsg41 = "<font color = \"red\">Sorry, but you used characters, and they are not allowed.</font><br>";
	}
	if ($iservice1 == 'nameservers'){
		if (strlen($nsa1) < 4 || strlen($nsa1) > 64) {
			$errormsg41 .= "<font color = \"red\">Sorry, but the ns record is too short or too long.</font><br>";
		}
	}
	return $errormsg41;
}

function check_nsa2($nsa2) {
global $iservice1;
	if(filter_var($nsa2, FILTER_VALIDATE_URL)){ 
		$errormsg42 = "<font color = \"red\">Sorry, but you used characters, and they are not allowed.</font><br>";
	}
	if ($iservice1 == 'nameservers' and $nsa2 != ''){
		if (strlen($nsa2) < 4 || strlen($nsa2) > 64) {
			$errormsg42 .= "<font color = \"red\">Sorry, but the ns record is too short or too long.</font><br>";
		}
	}
	return $errormsg42;
}

function check_url($url) {
global $iservice1;
	if ($iservice1 == 'forwarding'){
		if ($url==''){
			$errormsg7 = "<font color = \"red\">URL field is emptie.</font><br>";
			return $errormsg7;	
		}
	}
	if ($iservice1 == 'forwarding'){
		if (filter_var($url, FILTER_VALIDATE_URL, FILTER_FLAG_SCHEME_REQUIRED)!== false) {
		
		} else {
			$errormsg7 = "<font color = \"red\">Sorry, but your url is not correct or does not begin with http://</font><br>";
			return $errormsg7;
		}
	}
	if ($iservice1 == 'forwarding'){
		if (strlen($url) < 10 || strlen($url) > 255) {
			$errormsg7 .= "<font color = \"red\">Sorry, but the url is too short or too long.</font><br>";
		}
	}
	return $errormsg7;
}

function check_usernamenew($nsa) {
	if ($nsa==''){
		$errormsg = "<font color = \"red\">Username field is emptie.</font><br>";
		return $errormsg;	
	}
	if(preg_match('/[^a-zA-Z0-9\-\.]/',$nsa)) { 
		$errormsg = "<font color = \"red\">Sorry, but you used characters, and they are not allowed in the username.</font><br>";
		return $errormsg;
	}
	if (strlen($nsa) < 4 || strlen($nsa) > 63) {
		$errormsg .= "<font color = \"red\">Sorry, but the username is too short or too long.</font><br>";
		return $errormsg;
	}
	$sql441 = "SELECT id FROM users WHERE username1='$nsa'";       
   	$result441 = mysql_query($sql441) or die ("Couldn't execute query : " . mysql_error());      
	$num441 = mysql_num_rows($result441);                     
	if ($num441 != 0) {
		$errormsg .= "<font color = \"red\">Sorry, but the username is not free.</font><br>";
	}
	return $errormsg;
}

function check_username($nsa,$iuserid) {
	if ($nsa==''){
		$errormsg = "<font color = \"red\">Username field is emptie.</font><br>";
		return $errormsg;	
	}
	if(preg_match('/[^a-zA-Z0-9\-\.]/',$nsa)) { 
		$errormsg = "<font color = \"red\">Sorry, but you used characters, and they are not allowed in the username.</font><br>";
	}
	if (strlen($nsa) < 4 || strlen($nsa) > 63) {
		$errormsg .= "<font color = \"red\">Sorry, but the username is too short or too long.</font><br>";
	}
	$sql19 = "SELECT * FROM users WHERE id=$iuserid" ;
	$result19 = mysql_query($sql19) or die ("Couldn't execute query : " . mysql_error());
		while ($row19 = mysql_fetch_array($result19))
		{
		extract($row19);
		$iusername2 = $username1;
		}
	if ($nsa != $iusername2){
		$sql441 = "SELECT id FROM users WHERE username1='$nsa'";       
   		$result441 = mysql_query($sql441) or die ("Couldn't execute query : " . mysql_error());      
		$num441 = mysql_num_rows($result441);                     
		if ($num441 != 0) {
			$errormsg .= "<font color = \"red\">Sorry, but the username is not free.</font><br>";
		}
	}
	return $errormsg;
}

function check_string($string) { if(preg_match('/[^a-zA-Z0-9\-]/',$string)) { return 1; } else { return 0; } }

function verify_email($email) {
	if ($email==''){
		$errormsg = "<font color = \"red\">Emailaddress field is emptie.</font><br>";
		return $errormsg;	
	}
	if(filter_var(trim($email), FILTER_VALIDATE_EMAIL)){ 
	
	} else {
		$errormsg = "<font color = \"red\">Sorry, but you emailaddress is incorrect.</font><br>";
		return $errormsg;
	}
	if (strlen($email) < 4 || strlen($email) > 140) {
		$errormsg = "<font color = \"red\">Sorry, but your emailaddress is too short or too long.</font><br>";
		return $errormsg;
	}
	$sql441 = "SELECT * FROM users WHERE email1='$email'";       
   	$result441 = mysql_query($sql441) or die ("Couldn't execute query : " . mysql_error());      
	$num441 = mysql_num_rows($result441);                     
	if ($num441 != 0) {
		$errormsg = "<font color = \"red\">Sorry, but you have already a account.</font><br>";
		return $errormsg;
	}
return $errormsg;
}

function verify_email2($email,$iuserid) {
	if ($email==''){
		$errormsg = "<font color = \"red\">Emailadres field is emptie.</font><br>";
		return $errormsg;	
	}
	if(filter_var(trim($email), FILTER_VALIDATE_EMAIL)){ 
	} else {
		$errormsg = "<font color = \"red\">Sorry, but you email address is incorrect.</font><br>";
		return $errormsg;
	}
	if (strlen($email) < 4 || strlen($email) > 140) {
		$errormsg = "<font color = \"red\">Sorry, but your email address is too short or too long.</font><br>";
		return $errormsg;
	}
	$sql19 = "SELECT * FROM users WHERE id=$iuserid" ;
	$result19 = mysql_query($sql19) or die ("Couldn't execute query : " . mysql_error());
		while ($row19 = mysql_fetch_array($result19))
		{
		extract($row19);
		$iemail2 = $email1;
		}
	if ($email != $iemail2){
		$sql441 = "SELECT * FROM users WHERE email1='$email'";       
   		$result441 = mysql_query($sql441) or die ("Couldn't execute query : " . mysql_error());      
		$num441 = mysql_num_rows($result441);                     
		if ($num441 != 0) {
			$errormsg = "<font color = \"red\">Sorry, but this email address is already in or system.</font><br>";
			return $errormsg;
		}
	}
	return $errormsg;
}

function verify_email3($email) {
	if ($email==''){
	$errormsg = "<font color = \"red\">Emailadres field is emptie.</font><br>";
	return $errormsg;	
	}
	if(filter_var(trim($email), FILTER_VALIDATE_EMAIL)){ 
	} else {
	$errormsg = "<font color = \"red\">Sorry, but you email address is incorrect.</font><br>";
	return $errormsg;
	}
	if (strlen($email) < 4 || strlen($email) > 140) {
	$errormsg = "<font color = \"red\">Sorry, but your email address is too short or too long.</font><br>";
	return $errormsg;
	}
}

function ipaddress_check($ipaddresscheck1) {
$result501 = mysql_query("SELECT id FROM users WHERE ipaddress1='$ipaddresscheck1'") or die ("Couldn't execute query : " . mysql_error());
if(mysql_num_rows($result501)==0) { return 0; } else { return 1; } 
print "error";
return 1; 
} 

function ipaddress_check2($ipaddresscheck2) {
$result502 = mysql_query("SELECT id FROM users WHERE ipaddress1='$ipaddresscheck2'") or die ("Couldn't execute query : " . mysql_error());
if(mysql_num_rows($result502)==0) { return ""; } else { return "true"; }
return "error";
}

?>