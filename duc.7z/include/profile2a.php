<?php
if(define("liteB105", false)) die("Hacking System");

		$iusername = strtolower($_REQUEST["username1"]);
		$ifullname1 = $_REQUEST["fullname1"];
		$istreetnumber1 = $_REQUEST["streetnumber1"];		
		$ipostcode1 = $_REQUEST["postcode1"];
		$icity1 = $_REQUEST["city1"];
		$icountry1 = $_REQUEST["country1"];
		$iemail1 = strtolower($_REQUEST["email1"]);

########################## Check Username
$checkusername1 = check_username($iusername,$iuserid);

	if($checkusername1) {
		$usernamemessage = '<font color="#FF0000"><b>'.$checkusername1.'</b></font>';    
		include("include/website1b.php");	
		include("include/profile1a.php");
		include("include/website2.php");
		exit;
	}


############################# Check fullname

if(!$ifullname1 || strlen($ifullname1) > 70) {

	$namemessage = '<font color="#FF0000"><b><center>fullname not valid</center></b></font>';    
	include("include/website1b.php");	
	include("include/profile1a.php");
	include("include/website2.php");
	exit;
	}
	
#################### Check emailadres

$outputmsg1 = verify_email2($iemail1,$iuserid);

	if ($outputmsg1){
		$emailmessage = $outputmsg1 ;
		include("include/website1b.php");	
		include("include/profile1a.php");
		include("include/website2.php");
	exit;
	}

################## Now Save User #########################

	$sql19 = "SELECT * FROM users WHERE id=$iuserid" ;
	$result19 = mysql_query($sql19) or die ("Couldn't execute query : " . mysql_error());
		while ($row19 = mysql_fetch_array($result19))
		{
		extract($row19);
		$iuserid4 = $id ;
		$iusername4 = $username1 ;
		$ifullname4 = $fullname1 ;
		$istreetnumber4 = $streetnumber1 ;
		$ipostcode4 = $postcode1 ;
		$icity4 = $city1 ;
		$icountry4 = $country1 ;
		$iemail4 = $email1 ;
		$idate4 = $createdate1 ;
		$itime4 = $createtime1 ;
		$idate5 = $date1 ;
		$itime5 = $time1 ;
		$iipaddress4 = $ipaddress1 ;
		$maxdomains4 = $maxdomains1 ;	
		}	

	if ($iusername == $iusername4){
	if ($ifullname1 == $ifullname4){
	if ($istreetnumber1 == $istreetnumber4){ 
	if ($ipostcode1 == $ipostcode4){ 
	if ($icity1 = $icity4){
	if ($icountry1 == $icountry4){ 
	if ($iemail1 == $iemail4){

		$message = '<font color="#FF0000"><b><center>You did not change anything !<br>Please Klik on Back not Save!</center></b></font>';    
		
		include("include/website1b.php");	
		include("include/profile1a.php");
		include("include/website2.php");
		exit;
	}}}}}}}
	
		$sql6 = "UPDATE users SET username1='$iusername', fullname1='$ifullname1', streetnumber1='$istreetnumber1', postcode1='$ipostcode1', city1='$icity1', country1='$icountry1', email1='$iemail1', ipaddress1='$ipaddress', time1='$itodaytime', date1='$itodaydate' WHERE id='$iuserid'";
			
       	mysql_query($sql6) or die ("Couldn't execute query : " . mysql_error());


		################# Email me now  #######################
		
		$aemailadres1 = $noreplyemail ;
		
		$aemail_from = "from:". $aemailadres1 ;
		$aemail_to = $adminmail;
		$asubject = "Chance Registration User on domain : ". $maindomain ;

		$amessage = "Chance Registration User on domain ". $maindomain. "\n\n";
		$amessage .= "UsernameID : \t\t" . $iuserid . "\t\t\t\t\t" . $iuserid4 . "\n\n";
		$amessage .= "Username : \t\t" . $iusername . "\t\t\t\t\t" . $iusername4 . "\n";
		$amessage .= "Fullname : \t\t" . $ifullname1 . "\t\t\t\t" . $ifullname4 . "\n";
		$amessage .= "Street : \t\t" . $istreetnumber1 . "\t\t" . $istreetnumber4 . "\n";
		$amessage .= "Postcode : \t\t" . $ipostcode1 . "\t\t\t\t" . $ipostcode4 . "\n";
		$amessage .= "City : \t\t\t" . $icity1 . "\t\t\t\t\t" . $icity4 . "\n";
		$amessage .= "Country : \t\t" . $icountry1 . "\t\t\t\t" . $icountry4 . "\n\n";
		$amessage .= "Email : \t\t\t" . $iemail1 . "\t\t\t" . $iemail4 . "\n\n";
		$amessage .= "Change Time : \t\t\t" . $itodaytime . "\t\t\t\t" . $itime5 . "\n";
		$amessage .= "Change Date : \t\t\t" . $itodaydate . "\t\t\t\t" . $idate5 . "\n\n";
		$amessage .= "Create Time : \t\t" . $itime4 . "\n";
		$amessage .= "Create Date : \t\t" . $idate4 . "\n\n";
		$amessage .= "Max domains : \t\t" . $maxdomains4 . "\n\n";
		$amessage .= "IPaddress : \t\t" . $ipaddress . "\t\t\t\t" . $iipaddress4 . "\n";
		$amessage .= "-----------------------------------------------------------------------\n\n";
		$amessage .= "\n\n\n\n";

	if ( mail($aemail_to , $asubject , $amessage , $aemail_from ) ) {
	}
	else
	{
	$message = '<font color="#FF0000"><b>Error 36 : Mail not working.</b></font>';

	include("include/website1a.php");
	include("include/website2.php");
	exit;
	}

	$message = "Changing your account Complete"; ;
	include("include/website1c.php");	
	include("include/domainlist1a.php");
	include("include/website2.php");
	exit;
?>