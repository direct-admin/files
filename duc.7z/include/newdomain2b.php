<?php
if(define("liteB105", false)) die("Hacking System");

if ($iuserid == '') {	
	$message = '<font color="#FF0000"><b>Error no user id</b></font>';
	include("include/website1a.php");
	include("include/website2.php");
	exit;
	}	
	
	$idomainname = strtolower($maindomain);
	$inewdomainname0a = $_REQUEST["newdomainname1"];
	$inewdomainname1a = trim(strtolower($inewdomainname0a));
		
	$outputmsg = check_domain($inewdomainname1a);

	if ($outputmsg) {
		$newdomainname1message = $outputmsg ;
		include("include/website1c.php");
		include("include/newdomain1a.php");
		include("include/website2.php");
		exit;
	}
	
		$sql = "SELECT id FROM domains WHERE subdomainname1='$inewdomainname1a' and domainname1='$idomainname' LIMIT 2";       
   		$result = mysql_query($sql) or die ("Couldn't execute query : " . mysql_error());     
		$num = mysql_num_rows($result);                     
		if ($num >= 1) {

			$newdomainname1message = '<font color="#FF0000"><b>'.$inewdomainname1a.'.'.$maindomain.' '.'is not available'.'</b></font>';
			include("include/website1c.php");
			include("include/newdomain1a.php");
			include("include/website2.php");
			exit;
			
		} else {
					
		$sql29 = "SELECT * FROM users WHERE id='$iuserid' LIMIT 2"; 
        $result29 = mysql_query($sql29) or die ("Couldn't execute query : " . mysql_error());   
        $num29 = mysql_num_rows($result29);
        if ($num29 == 1) {
			while ($row29 = mysql_fetch_array($result29))
			{
				extract($row29);
				$imaxdomains1 = $maxdomains1;
			}
	
		 if  ($imaxdomains1 == 0) {
		 	$newdomainname1message = "<font color=red>Error no maximum domains set in database.<br></font>";			
		 	include("include/website1c.php");
			include("include/newdomain1a.php");
			include("include/website2.php");
		 	exit;
		 }

		 $sql5 = "SELECT id FROM domains WHERE userid='$iuserid' LIMIT 2";
		 $result5 = mysql_query($sql5) or die ("Couldn't execute query : " . mysql_error());
         $num5 = mysql_num_rows($result5);
         if ($num5 >= $imaxdomains1) {
			$newdomainname1message = "<font color=red>Sorry but you have the maximal domains of ".$imaxdomains1." on your account.<br></font> ";			
		 	include("include/website1c.php");
			include("include/newdomain1a.php");
			include("include/website2.php");
		 	exit;	
		 }
			
	$iurl1 = "http://www.".$idomainname."/newdomain/";
		 
	$sq128 = "INSERT INTO domains (id, subdomainname1, domainname1, userid, domainlock1, service1, url1, date1, time1) VALUES ('', '$inewdomainname1a', '$idomainname', $iuserid, 0, 'forwarding', '$iurl1', '$itodaydate', '$itodaytime')";

	mysql_query($sq128) or die ("Couldn't execute query : " . mysql_error());

	$sql6 = "SELECT id FROM domains WHERE userid='$iuserid' AND subdomainname1='$inewdomainname1a'";
	$result6 = mysql_query($sql6) or die ("Couldn't execute query : " . mysql_error()); 
	$num6 = mysql_num_rows($result6);
    if ($num6 == 1) {
		while ($row6 = mysql_fetch_array($result6))
		{
			extract($row6);
			$idomainid = $id;
		}
	} else { print "error"; exit;}
 	$isubdomainname2 = $inewdomainname1a.'.'.$idomainname;
 
	$sql22 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES ('', $powerdns_domain_id1, '$isubdomainname2', 'A', '$server_ipaddress', 300, 0, $cdate4, '$inewdomainname1a', '1', $idomainid)";
		mysql_query($sql22) or die ("Couldn't execute query : " . mysql_error());
		 
			$message = '<font color="green"><b>The domain is registrated to you.<br>You can now change the settings of the domain.</b></font>';
			include("include/website1c.php");	
 			include("include/domainlist1a.php");
			include("include/website2.php");
			exit;
			
		} else {
			
			$newdomainname1message = '<font color="#FF0000"><b>ERROR 1 ! : No userid</b></font>';      
			include("include/website1c.php");
			include("include/newdomain1a.php");
			include("include/website2.php");
			exit;
		}		
	}
?>