<link href="../css/style.css" rel="stylesheet" type="text/css">
<?php
if(define("liteB105", false)) die("Hacking System");

#######################

		$adata = "";
		$tekens1 = array_merge(range('A', 'Z'), range(0, 9));
		for ($i1 = 0; $i1 < 8; $i1++) { $adata .= $tekens1[rand(0, count($tekens1) - 1)]; }
		$auserid1 = $iuserid;
		$adomainid1 = 0;
		$adate1 = date("dmy");

		$sql1 = "INSERT INTO data1 ( data, userid, domainid, date) VALUES ('$adata', $auserid1, $adomainid1, '$adate1')";
		mysql_query($sql1) or die ("no. 1 Couldn't execute query : " . mysql_error());				

#######################
print "<br>".$message."<br>";
?>
</center>
<form action="index.php?in=activation1" method="POST">
<input type="hidden" name="data" value="<?php echo @$adata ?>">
  <table width="610" border="0" cellpadding="0" align="center">
    <tr>
      <td colspan="3" class="text2"><?php echo "$Activate_your_account"; ?></td>
      </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><?php echo "$Please_enter_here_your_activation_code_in"; ?></td>
      <td><input name="activation1" type="text" class="input1" value="" size="15" maxlength="10" /></td>
      <td><input name="submit" type="submit" value='Activate' /></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
        <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
        <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    </table>
    </form>
</center>