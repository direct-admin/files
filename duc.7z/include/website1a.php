<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title><?php echo "$maindomain2ext"; ?><?php echo "$maindomainext"; ?> - Free Domain Registration + Free DNS Service.</title>
    <meta name="description" content="Free Domain Names with full DNS control. Get Your Free Domain Name - Free Dynamic DNS Service. With Full DNS Support, 100% Free Domain Registration - No Ads">
    <meta name="keywords" content="free domain registration, free domain names, register a domain name, web domain name, internet domain registration, cheap internet domain registration, free domain name, free domains">
<link rel="shortcut icon" href="favicon.ico" >
<link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor="#dfdfdf" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" height="40" border="0" cellpadding="0" cellspacing="0" class="style1" id="tabel1">
  <tr>
    <td width="30%" height="42">
    <div align="right">
	<a href="../index.php" class="style9" rel="nofollow"><span class="style8a"><?php echo "$maindomain2ext"; ?></span><span class="style8b"><?php echo "$maindomainext"; ?></span></a>
	</div>
    </td>
    <td width="*">&nbsp;</td>
    <td width="12%"><form action="index.php?in=register2" method="POST"><input type='submit' name='enter' value='<?php echo "$top_Create_a_new_account"; ?>'></form></td>
    <td width="12%">&nbsp;</td>
    <td width="12%"><form action="index.php?in=login" method="POST"><input type='submit' name='enter' value='<?php echo "$top_My_Account"; ?>'></form></td>
    <td width="12%">&nbsp;</td>
    <td width="10%">&nbsp;</td>
  </tr>
</table>
</form>
<table width="100%" height="150" border="0" cellpadding="0" cellspacing="0" class="style2" id="tabel2">
  <tr>
    <td width="350">&nbsp;</td>
    <td width="450">
    <h1 class="style6">free <span class="style5">domain</span> registration</h1>            
<span class="style12"><strong>Get Your Free Domain Name - Free Dynamic DNS Service.</strong><br><strong>With Full DNS Support, 100% Free Domain Names - No Ads!</strong></span>
    </td>
    <td width="*">&nbsp;</td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="style2" id="tabel3">
   <tr>
    <td height="25">&nbsp;</td>
  </tr>
</table>
<form action="index.php?in=checkdomain" method="POST">
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="style2" id="tabel4">
   <tr height="5">
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td width="250">&nbsp;</td>
    <td width="50" align="right"><span class="style3">www.&nbsp;</span></td>
    <td width="180" align="left"><input name="domain" type="text" class="style4" size="30" maxlength="60" /></td>
    <td width="250" align="left"><span class="style3">&nbsp;.<?php echo "$maindomain"; ?></span></td>
    <td width="*">&nbsp;</td>
  </tr>
   <tr height="5">
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="left"><span class="style7"><?php echo "$example_www_yourname"; ?><?php echo "$maindomain"; ?></span></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="style2" id="tabel5">
   <tr>
    <td height="25">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="style2" id="tabel6">  
   <tr>
    <td align="center"><input type="image" src="images/check.gif" width="189" height="44" border="0" name="checkButton" onClick="submit" /></td>
  </tr>
</table>
</form>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="style2" id="tabel7">
   <tr>
    <td height="25">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="right"><font size=-3><?php echo "$top_Version $version1 &nbsp;&nbsp;"; ?></font></td>
  </tr>
</table>
<br><center><font color=#FF0000><b>THIS SITE IS STILL IN BETA VERSION AND SUBDOMAINS MAY STILL BE REMOVED.</b></font></center><br>
<br />
<br />
<center>
<?php                                                   
if (isset($message)) echo "<span class='style14b'>$message</span>";
?>
</center>
<br />
<br />
<br />
<br />
<br />