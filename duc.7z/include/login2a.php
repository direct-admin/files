<?php
if(define("liteB105", false)) die("Hacking System");
			
		$iusername = strtolower(trim($_REQUEST["username1"]));
		$ipassword = trim($_REQUEST["password1"]);
		
		if ($iusername == '') {
			$message = '<font color="#FF0000"><b>no username</b></font>';
			include("include/website1a.php");
			include("include/website2.php");
			exit;
		}

		if ($ipassword == '') {
			$message = '<font color="#FF0000"><b>no password</b></font>';
			include("include/website1a.php");
			include("include/website2.php");
			exit;
		}

	 	$sql1 = "SELECT id,password1,maxdomains1,activationcode1 FROM users WHERE username1='$iusername' LIMIT 1";
      	$result1 = mysql_query($sql1) or die ("No.1 Couldn't execute query : " . mysql_error());      
		$num1 = mysql_num_rows($result1);                     
		if ($num1 == 1)             
		{		 
			while ($row1 = mysql_fetch_array($result1))
			{
				extract($row1);
				$iuserid = $id;
				$hash_password2 = $password1;
				$imaxdomains1 = $maxdomains1;
				$iactivationcode1 = $activationcode1;
			}

			if (validate_password($ipassword,$hash_password2)) {
				
			} else {
				$message="<font color=red>incorred password<br></font>";
           		include("include/website1a.php");
				include("include/website2.php");
		   		exit;
			}

		if ($iactivationcode1!='') {
			
		 	include("include/website1c.php");
		 	include("include/activation1a.php");
		 	include("include/website2.php");
		 	exit;	
		}
	
		 
		 $sql102 = "UPDATE users SET logindate='$itodaydate' WHERE id=$iuserid" ;
		 mysql_query($sql102) or die ("1 Couldn't execute query : " . mysql_error());
		 
		 include("include/website1c.php");	
		 include("include/domainlist1a.php");
		 include("include/website2.php");
		 exit;		 	
	
      	} else {            
	  
        	$message = "<font color=red>incorred username<br></font>";
        	include("include/website1a.php");
			include("include/website2.php");
			exit;
        }
?>