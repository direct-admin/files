<?php
if(define("liteB105", false)) die("Hacking System");

	$data = $_REQUEST["data"];

	 	$sql1 = "SELECT id,userid,domainid,date FROM data1 WHERE data='$data' LIMIT 1";
      	$result1 = mysql_query($sql1) or die ("no. 1 Couldn't execute query : " . mysql_error());      
		$num1 = mysql_num_rows($result1);                     
		if ($num1 == 1) {
			while ($row1 = mysql_fetch_array($result1))
			{
				extract($row1);
				$id = $id;
				$iuserid = $userid;
				$idomainid = $domainid;
				$date = $date;
			}
			
			$sql3 = "DELETE FROM data1 WHERE id=$id" ;
    		mysql_query($sql3) or die ("no. 3 Couldn't execute query : " . mysql_error());	
			
			$itodaydate3=date("Ymd", mktime(0, 0, 0, date("m"), date("d")-2, date("Y")));
			
			$sql4 = "DELETE FROM data1 WHERE userid=$iuserid AND domainid=$idomainid ";
			mysql_query($sql4) or die ("no. 4 Couldn't execute query : " . mysql_error());	

			$sql4 = "DELETE FROM data1 WHERE date<=$itodaydate3";
			mysql_query($sql4) or die ("no. 4 Couldn't execute query : " . mysql_error());		
		
		} else {
			$message = '<font color="#FF0000"><b>Error code(D1) incorrect</b></font>';
			include("include/website1a.php");
			include("include/website2.php");
			exit;	
		}
?>