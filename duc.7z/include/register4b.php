<?php
if(define("liteB105", false)) die("Hacking System");

		$sql19 = "SELECT * FROM domains WHERE id=$idomainid and userid=$iuserid LIMIT 1" ;
		$result19 = mysql_query($sql19) or die ("1 Couldn't execute query : " . mysql_error());
		while ($row19 = mysql_fetch_array($result19))
		{
		extract($row19);
		$isubdomainname1 = $subdomainname1;
		$idomainname1= $domainname1;
		}
		
		$idomainname1 = strtolower(trim($idomainname1));
		$isubdomainname1 = strtolower(trim($isubdomainname1));
		$isubdomainname2 = $isubdomainname1 . '.' . $idomainname1 ;
		
		$iservice1 = $_REQUEST["service"];

		$inameserver11 = strtolower(trim($_REQUEST["nameserver1"]));
		$inameserver21 = strtolower(trim($_REQUEST["nameserver2"]));
		
		$iipaddress1 = strtolower(trim($_REQUEST["ipaddress"]));
		$iipaddress2 = strtolower(trim($_REQUEST["ipaddress2"]));
		
		$iurl1 = strtolower(trim($_REQUEST["url"]));
		
		$imicrosoftmx1 = trim($_REQUEST["microsoftmx"]);
		$igoogletxt1 = trim($_REQUEST["googletxt"]);
	
	if ($iuserid == '')
	{		
				$message = '<font color="#FF0000"><b>no userid</b></font>';
				include("include/website1c.php");
				include("include/register5a.php");
				include("include/website2.php");
				exit;	
	}

		$outputmsg1 = check_nsa1($inameserver11);
		$outputmsg2 = check_nsa2($inameserver21);

		if ($outputmsg1) {
		$nameserver1message = $outputmsg1 ;
		$exityes=1;
		}
		if ($outputmsg2) {
		$nameserver2message = $outputmsg2 ;
		$exityes=1;
		}
		
		if ($iipaddress1!=="") { $outputmsg3 = check_ipv4a($iipaddress1); }

		if ($outputmsg3) {
		$ipaddressmessage = $outputmsg3 ;
		$exityes=1;
		}

		if ($iipaddress2!=="") { $outputmsg8 = check_ipv6a($iipaddress2); }

		if ($outputmsg8) {
		$ipaddressmessage2 = $outputmsg8 ;
		$exityes=1;
		}

		$outputmsg7 = check_url($iurl1);

		if ($outputmsg7) {
		$urlmessage1 = $outputmsg7 ;
		$exityes=1;
		}		
		
	
		if ($exityes == 1){
		include("include/website1c.php");	
		include("include/register5a.php");
		include("include/website2.php");
		exit;
		}


		$sq28 = "UPDATE domains SET 
		service1='$iservice1', 
		nameserver1='$inameserver11', 
		nameserver2='$inameserver21', 
		ipaddress1='$iipaddress1', 
		ipaddress2='$iipaddress2', 
		url1='$iurl1',
		googletxt='$igoogletxt1', 
		microsoftmx='$imicrosoftmx1'  
		WHERE id='$idomainid'";	

		mysql_query($sq28) or die ("2 Couldn't execute query : " . mysql_error());


if ($iservice1 == "nameservers")  {

$sql17 = "DELETE FROM powerdnsdata1.records WHERE domain_id='$powerdns_domain_id1' AND domainid='$idomainid'" ;
mysql_query($sql17) or die ("3 Couldn't execute query : " . mysql_error());

$qcontent3=$inameserver11;

if ($qcontent3!=""){

$sql20 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, '$isubdomainname2', 'NS', '$qcontent3', 3600, 0, $cdate4, '$isubdomainname1', '1', $idomainid)";
mysql_query($sql20) or die ("4 Couldn't execute query : " . mysql_error());

}

$qcontent4=$inameserver21;

if ($qcontent4!=""){

$sql21 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, '$isubdomainname2', 'NS', '$qcontent4', 3600, 0, $cdate4, '$isubdomainname1', '1', $idomainid)";
mysql_query($sql21) or die ("5 Couldn't execute query : " . mysql_error());

}}
##############################################################

if ($iservice1 == "zonerecords")  {

$sql17 = "DELETE FROM powerdnsdata1.records WHERE domain_id='$powerdns_domain_id1' AND domainid='$idomainid'" ;
mysql_query($sql17) or die ("6 Couldn't execute query : " . mysql_error());


$qcontent1="$iipaddress1";

if ($qcontent1 !=""){
	
$sql22 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, '$isubdomainname2', 'A', '$qcontent1', 3600, 0, $cdate4, '$isubdomainname1', '1', $idomainid)";
mysql_query($sql22) or die ("Couldn't execute query : " . mysql_error());
}

$qcontent2="$iipaddress2";

if ($qcontent2 !=""){

$sql23 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, '$isubdomainname2', 'AAAA', '$qcontent2', 3600, 0, $cdate4, '$isubdomainname1', '1', $idomainid)";
mysql_query($sql23) or die ("Couldn't execute query : " . mysql_error());

} }
##############################################################

if ($iservice1 == "googleservice")  {

$sql17 = "DELETE FROM powerdnsdata1.records WHERE domain_id='$powerdns_domain_id1' AND domainid='$idomainid'" ;
mysql_query($sql17) or die ("Couldn't execute query : " . mysql_error());

$qcontent1="$igoogletxt1";

if ($qcontent1 !=""){

$sql29 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, '$isubdomainname2', 'TXT', '$qcontent1', 3600, 0, $cdate4, '$isubdomainname1', '1', $idomainid)";
mysql_query($sql29) or die ("Couldn't execute query : " . mysql_error());

$sql30 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, 'mail.$isubdomainname2', 'CNAME', 'ghs.googlehosted.com', 3600, 0, $cdate4, '$isubdomainname1 mail', '1', $idomainid)";
mysql_query($sql30) or die ("Couldn't execute query : " . mysql_error());

$sql31 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, 'calendar.$isubdomainname2', 'CNAME', 'ghs.googlehosted.com', 3600, 0, $cdate4, '$isubdomainname1 calendar', '1', $idomainid)";
mysql_query($sql31) or die ("Couldn't execute query : " . mysql_error());

$sql32 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, 'docs.$isubdomainname2', 'CNAME', 'ghs.googlehosted.com', 3600, 0, $cdate4, '$isubdomainname1 docs', '1', $idomainid)";
mysql_query($sql32) or die ("Couldn't execute query : " . mysql_error());

$sql33 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, 'sites.$isubdomainname2', 'CNAME', 'ghs.googlehosted.com', 3600, 0, $cdate4, '$isubdomainname1 sites', '1', $idomainid)";
mysql_query($sql33) or die ("Couldn't execute query : " . mysql_error());

$sql33 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, 'www.$isubdomainname2', 'CNAME', 'ghs.googlehosted.com', 3600, 0, $cdate4, '$isubdomainname1 www', '1', $idomainid)";
mysql_query($sql33) or die ("Couldn't execute query : " . mysql_error());

$sql34 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, '$isubdomainname2', 'TXT', 'v=spf1 include:_spf.google.com ~all', 3600, 0, $cdate4, '$isubdomainname1', '1', $idomainid)";
mysql_query($sql34) or die ("Couldn't execute query : " . mysql_error());

$sql37 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, '$isubdomainname2', 'MX', 'ASPMX.L.GOOGLE.COM', 3600, 10, $cdate4, '$isubdomainname1', '1', $idomainid)";
mysql_query($sql37) or die ("Couldn't execute query : " . mysql_error());

$sql38 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, '$isubdomainname2', 'MX', 'ALT1.ASPMX.L.GOOGLE.COM', 3600, 20, $cdate4, '$isubdomainname1', '1', $idomainid)";
mysql_query($sql38) or die ("Couldn't execute query : " . mysql_error());

$sql39 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, '$isubdomainname2', 'MX', 'ALT2.ASPMX.L.GOOGLE.COM', 3600, 30, $cdate4, '$isubdomainname1', '1', $idomainid)";
mysql_query($sql39) or die ("Couldn't execute query : " . mysql_error());

$sql40 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, '$isubdomainname2', 'MX', 'ASPMX2.GOOGLEMAIL.COM', 3600, 40, $cdate4, '$isubdomainname1', '1', $idomainid)";
mysql_query($sql40) or die ("Couldn't execute query : " . mysql_error());

$sql41 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, '$isubdomainname2', 'MX', 'ASPMX3.GOOGLEMAIL.COM', 3600, 50, $cdate4, '$isubdomainname1', '1', $idomainid)";
mysql_query($sql41) or die ("Couldn't execute query : " . mysql_error());

} }
##############################################################

if ($iservice1 == "microsoftlive")  {

$sql17 = "DELETE FROM powerdnsdata1.records WHERE domain_id='$powerdns_domain_id1' AND domainid='$idomainid'" ;
mysql_query($sql17) or die ("Couldn't execute query : " . mysql_error());

$qcontent1=$imicrosoftmx1;
$qcontent20 = explode(".", $qcontent1);
$qcontent2=$qcontent20[0];

if ($qcontent1 !=""){

$sql30 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, '$isubdomainname2', 'MX', '$qcontent1', 3600, 10, $cdate4, '$isubdomainname1', '1', $idomainid)";
mysql_query($sql30) or die ("Couldn't execute query : " . mysql_error());

$sql31 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, '$isubdomainname2', 'TXT', 'v=msv1 t=$qcontent2', 3600, 0, $cdate4, '$isubdomainname1', '1', $idomainid)";
mysql_query($sql31) or die ("Couldn't execute query : " . mysql_error());

$sql32 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, '$isubdomainname2', 'MX', '$qcontent2.msv1.invalid', 3600, 90, $cdate4, '$isubdomainname1', '1', $idomainid)";
mysql_query($sql32) or die ("Couldn't execute query : " . mysql_error());

$sql33 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, '$isubdomainname2', 'TXT', 'v=spf1 include:hotmail.com ~all', 3600, 0, $cdate4, '$isubdomainname1', '1', $idomainid)";
mysql_query($sql33) or die ("Couldn't execute query : " . mysql_error());

$sql34 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, '_sipfederationtls._tcp.$isubdomainname2', 'SRV', '10 2 5061 federation.messenger.msn.com', 3600, 10, $cdate4, '$isubdomainname1 _tcp _sipfederationtls', '1', $idomainid)";
mysql_query($sql34) or die ("Couldn't execute query : " . mysql_error());

$sql35 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, 'mail.$isubdomainname2', 'CNAME', 'domains.live.com', 3600, 0, $cdate4, '$isubdomainname1 mail', '1', $idomainid)";
mysql_query($sql35) or die ("Couldn't execute query : " . mysql_error());

$sql36 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, 'map.$isubdomainname2', 'CNAME', 'domains.live.com', 3600, 0, $cdate4, '$isubdomainname1 map', '1', $idomainid)";
mysql_query($sql36) or die ("Couldn't execute query : " . mysql_error());

$sql37 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, 'profile.$isubdomainname2', 'CNAME', 'domains.live.com', 3600, 0, $cdate4, '$isubdomainname1 profile', '1', $idomainid)";
mysql_query($sql37) or die ("Couldn't execute query : " . mysql_error());

$sql38 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, 'photos.$isubdomainname2', 'CNAME', 'domains.live.com', 3600, 0, $cdate4, '$isubdomainname1 photos', '1', $idomainid)";
mysql_query($sql38) or die ("Couldn't execute query : " . mysql_error());

$sql39 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, 'skydrive.$isubdomainname2', 'CNAME', 'domains.live.com', 3600, 0, $cdate4, '$isubdomainname1 skydrive', '1', $idomainid)";
mysql_query($sql39) or die ("Couldn't execute query : " . mysql_error());

$sql40 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, 'groups.$isubdomainname2', 'CNAME', 'domains.live.com', 3600, 0, $cdate4, '$isubdomainname1 groups', '1', $idomainid)";
mysql_query($sql40) or die ("Couldn't execute query : " . mysql_error());

$sql41 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, 'calendar.$isubdomainname2', 'CNAME', 'domains.live.com', 3600, 0, $cdate4, '$isubdomainname1 calendar', '1', $idomainid)";
mysql_query($sql41) or die ("Couldn't execute query : " . mysql_error());

} }
##############################################################
if ($iservice1 == "noservice")  {
	
$sql17 = "DELETE FROM powerdnsdata1.records WHERE domain_id='$powerdns_domain_id1' AND domainid='$idomainid'" ;
mysql_query($sql17) or die ("Couldn't execute query : " . mysql_error());
	
}
##############################################################

if ($iservice1 == "forwarding")  {

$sql17 = "DELETE FROM powerdnsdata1.records WHERE domain_id='$powerdns_domain_id1' AND domainid='$idomainid'" ;
mysql_query($sql17) or die ("Couldn't execute query : " . mysql_error());

$sql22 = "INSERT INTO powerdnsdata1.records (id, domain_id, name, type, content, ttl, prio, change_date, ordername, auth, domainid) VALUES
('', $powerdns_domain_id1, '$isubdomainname2', 'A', '$server_ipaddress', 3600, 0, $cdate4, '$isubdomainname1', '1', $idomainid)";
mysql_query($sql22) or die ("Couldn't execute query : " . mysql_error());

}
##############################################################

$rdata2 = $dnssoa1." ".date("YmdH")." ".$dnssoa2;
$sq23 = "UPDATE powerdnsdata1.records set content='$rdata2',change_date=$cdate4 WHERE domain_id=$powerdns_domain_id1 AND type='SOA' AND domainid=0" ;
mysql_query($sq23) or die ("10 Couldn't execute query : " . mysql_error());

		$message = "<font color='#000000'><b>Record registration complete !</b><br><br>Important: It may take up to 48 hours for changes made to our zone records to<br>become effective. This is because of the number of networks and agencies involved.<br>Delays apply to all domains and registrars. Please allow for this delay<br>when planning Web sites or configuring a domain.</font><br>";
	 
		 include("include/website1c.php");	
		 include("include/domainlist1a.php");
		 include("include/website2.php");
		 exit;		 

?>