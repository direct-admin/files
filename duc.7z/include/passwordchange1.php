<link href="../css/style.css" rel="stylesheet" type="text/css">
<?php
if(define("liteB105", false)) die("Hacking System");

#######################

		$adata = "";
		$tekens1 = array_merge(range('A', 'Z'), range(0, 9));
		for ($i1 = 0; $i1 < 8; $i1++) { $adata .= $tekens1[rand(0, count($tekens1) - 1)]; }
		$auserid1 = $iuserid;
		$adomainid1 = 0;
		$adate1 = date("dmy");

		$sql1 = "INSERT INTO data1 ( data, userid, domainid, date) VALUES ('$adata', $auserid1, $adomainid1, '$adate1')";
		mysql_query($sql1) or die ("no. 1 Couldn't execute query : " . mysql_error());				

#######################

?>
</center>
    <br />
    <form name="form01" method="post" action="../index.php?in=passwordchange2">
    <input type="hidden" name="data" value="<?php echo @$adata ?>">
<table border="0" align="center">
    <tr>
      <td colspan="3" class="text2"><?php echo "$Chance_your_password"; ?></td>
      </tr>
    <tr>
      <td colspan="3">&nbsp;</td>
      </tr>
    <tr>
      <td >&nbsp;</td>
      <td >&nbsp;</td>
      <td >&nbsp;</td>
    </tr>
    <tr>
      <td><?php echo "$Your_current_password"; ?></td>
      <td>&nbsp;</td>
      <td><input name="password1" class="input1" type="password" value="" size="35" maxlength="40"></td>
    </tr>
<?php                                                   
if (isset($currentpasswordmessage)) { Print "
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>".$currentpasswordmessage."</td>
    </tr> "; }
?>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><?php echo "$Your_new_password"; ?></td>
      <td>&nbsp;</td>
      <td><input name="password2" type="password" class="input1" value="" size="35" maxlength="40" /></td>
    </tr>
    <tr>
      <td><?php echo "$Repeat_your_new_password"; ?></td>
      <td>&nbsp;</td>
      <td><input name="password3" type="password" class="input1" value="" size="35" maxlength="40" /></td>
    </tr>
<?php                                                   
if (isset($newpasswordmessage)) { Print "
   <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>".$newpasswordmessage."</td>
    </tr>";
}
?>    
    
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
  <br />
<table width="610" border="0" align="center" cellpadding="0">
  <tr>
  <td width="215">&nbsp;</td>
  <td width="182"><input name="submit" type="submit" value='<?php echo "$Save_New_Password"; ?>' /></td>
  <td width="205"></td>
  </tr>
  </table>
</form>
                      
<form name="form02" method="post" action="../index.php?in=login9">
    <input type="hidden" name="data" value="<?php echo @$adata ?>">
<table width="610" border="0" align="center" cellpadding="0">
   <tr>
    <td width="190">&nbsp;</td>
    <td width="22">&nbsp;</td>
    <td width="387" align="right"><input type="submit" value='<?php echo "$Back"; ?>' /></td>
    </tr>
</table>
</form>
</center>
