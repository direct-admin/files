<link href="../css/style.css" rel="stylesheet" type="text/css">
<?php
print "<br>".$message."<br>";
?>
</center>
<form action="index.php?in=login1" method="POST">
  <table width="610" border="0" cellpadding="0" align="center">
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td colspan="3" class="text2"><?php echo "$My_Account_Login"; ?></td>
      </tr>
    <tr>
      <td><?php echo "$Username"; ?></td>
      <td>&nbsp;</td>
      <td><input name="username1" class="input1" type="text" value="" size="40" maxlength="35" /></td>
    </tr>
    <tr>
      <td><?php echo "$Password"; ?></td>
      <td>&nbsp;</td>
      <td><input name="password1" type="password" class="input1" value="" size="40" maxlength="35" /></td>
    </tr>
   <tr>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  <td><input name="submit" type="submit" value='<?php echo "$Login"; ?>' /></td>
  </tr>
    </table>
    </form>
    
</center>
