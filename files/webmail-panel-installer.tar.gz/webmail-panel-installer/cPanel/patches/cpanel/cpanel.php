<?php

	$sUserLogin = isset($_SERVER['REMOTE_USER']) ? $_SERVER['REMOTE_USER'] : '';
	$sUserPassword = isset($_SERVER['REMOTE_PASSWORD']) ? $_SERVER['REMOTE_PASSWORD'] : '';
	$sUserEmail = $sUserLogin;

	$iPos=strpos($sUserPassword,"[::cpses::]");
	if ($iPos!==FALSE) {
	    $sKey = substr($sUserPassword,0,$iPos);
	    $sUserLogin.="/".$sKey;
	}

	include __DIR__.'/../libraries/afterlogic/api.php';

	$oException = null;
	$oApiIntegratorManager = /* @var $oApiIntegratorManager CApiIntegratorManager */ CApi::Manager('integrator');

	try
	{
		if ($oApiIntegratorManager)
		{
			$oAccount = $oApiIntegratorManager->LoginToAccountCpanel($sUserEmail, $sUserPassword, $sUserLogin);
			if ($oAccount instanceof CAccount)
			{
				$oApiIntegratorManager->SetAccountAsLoggedIn($oAccount);
				CApi::Location('../');
				exit();
			}
		}
	}
	catch (Exception $oException)
	{

	}

	$sError = '';
	if ($oException)
	{
		$sError = trim($oException->getMessage());
	}

	$sError =  empty($sError) ? ($oApiIntegratorManager ? $oApiIntegratorManager->GetLastErrorMessage() : '') : $sError;
	echo empty($sError) ? 'Internal Server Error. Please, contact your system administrator in order to report the problem.' : $sError;

	exit();
