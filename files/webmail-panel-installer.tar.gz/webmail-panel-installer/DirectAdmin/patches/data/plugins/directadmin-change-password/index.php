<?php

CApi::Inc('common.plugins.change-password');

class CDirectAdminChangePasswordPlugin extends AApiChangePasswordPlugin
{
	/**
	 * @var CDomain
	 */
	protected $oDefaultDomain;

	/**
	 * @var DirectAdminAPI
	 */
	private $oDAApi;

	/**
	 * @param CApiPluginManager $oPluginManager
	 */
	public function __construct(CApiPluginManager $oPluginManager)
	{
		parent::__construct('1.0', $oPluginManager);

		$this->oDefaultDomain = null;

		require_once __DIR__.'/da_api.php';
		$this->oDAApi = new DirectAdminAPI('http://localhost:2222');
	}

	/**
	 * @param CAccount $oAccount
	 * @return bool
	 */
	public function ValidateIfAccountCanChangePassword($oAccount)
	{
		if (null === $this->oDefaultDomain)
		{
			/* @var $oApiDomainsManager CApiDomainsManager */
			$oApiDomainsManager = CApi::Manager('domains');
			if ($oApiDomainsManager)
			{
				$this->oDefaultDomain = $oApiDomainsManager->GetDefaultDomain();
			}
		}
		
		return (
			$this->oDefaultDomain &&
			$oAccount instanceof CAccount &&
			$this->oDefaultDomain->IncomingMailServer === $oAccount->IncomingMailServer
		);
	}

	/**
	 * @param CAccount $oAccount
	 */
	public function ChangePasswordProcess($oAccount)
	{
		if ($oAccount instanceof CAccount && 0 < strlen($oAccount->PreviousMailPassword) &&
			$oAccount->PreviousMailPassword !== $oAccount->IncomingMailPassword)
		{
		    $this->oDAApi->CMD_CHANGE_EMAIL_PASSWORD(
				$oAccount->IncomingMailLogin,
				$oAccount->PreviousMailPassword,
				$oAccount->IncomingMailPassword,
				$oAccount->IncomingMailPassword
		    );
		}
	}
}

return new CDirectAdminChangePasswordPlugin($this);
