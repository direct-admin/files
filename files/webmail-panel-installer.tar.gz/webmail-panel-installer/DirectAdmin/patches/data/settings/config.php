<?php

return array(
    'plugins.directadmin-change-password' => true
);
