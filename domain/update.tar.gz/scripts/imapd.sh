#!/bin/sh

DA_PATH=/usr/local/directadmin
FILE=${DA_PATH}/scripts/packages/imapd
DEST=/usr/sbin/imapd

if [ ! -e $FILE ]; then
        echo "Unable to find: $FILE";
        exit 1;
fi

/bin/cp -f $FILE $DEST
/bin/chown root:root $DEST
/bin/chmod 755 $DEST


COUNT=`/bin/cat /etc/inetd.conf |/bin/grep -c -e '^imap2'`
if [ $COUNT = 0 ]; then
        echo -e "imap2\tstream\ttcp\tnowait\troot\t/usr/sbin/imapd\timapd" >> /etc/inetd.conf

        /bin/kill `cat /var/run/inetd.pid`
        /usr/sbin/inetd

fi

exit 0;
