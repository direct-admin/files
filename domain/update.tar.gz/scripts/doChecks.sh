#!/bin/sh

#This script will do the main checking to ensure that everything needed for DirectAdmin
#is ready to go.

if [ ! -e /etc/debian_version ]; then
	echo "cannot find /etc/debian_version.  This is not a debian system, but this install package is for debian.  Update your license to the correct OS before installing.";

	if [ -s /etc/redhat-release ]; then
		echo "Your /etc/redhat-release says you're using:";
		cat /etc/redhat-release;
		uname -m
	fi

	OS=`uname`
	if [ "${OS}" = "FreeBSD" ]; then
		echo "The uname program says you're using:"
		echo "FreeBSD `uname -rm`"
	fi

	exit 1;
fi

#STEP 1: Make sure we have a /home partition

RET=0;
HOMEYES=`cat /etc/fstab | grep -c /home`;
if [ $HOMEYES -lt "1" ]
then
	#echo "*** You require a /home parition ***";
	#RET=1;
	
	#don't abort, we can do it still... just have to modify the conf file.
	echo 'quota_partition=/' >> /usr/local/directadmin/data/templates/directadmin.conf;
fi

#check for /etc/shadow.. need to have it for passwords
if [ ! -s /etc/shadow ]
then
	echo "*** Cannot find the /etc/shadow file used for passwords. Use 'pwconv' ***";
	RET=1;
fi

#STEP 1: Make sure we have named installed
#we do this by checking for named.conf and /var/named

if [ ! -s /usr/sbin/named ]
then
	echo "*** Cannot find the named binary. Please install Bind ***";
	RET=1;
fi

has_local_listen()
{
	if [ ! -s $1 ]; then
		echo "0";
		return;
	fi
	
	COUNT4=`cat $1 | grep listen-on | grep -c 127.0.0.1`
	COUNT6=`cat $1 | grep listen-on-v6 | grep -c ::1`
	if [ "$COUNT4" -gt 0 ] || [ "$COUNT6" -gt 0 ]; then
		echo "1";
	else
		echo "0";
	fi
}

GET_NAMED_CONF=0
if [ -s /etc/bind/named.conf ]; then
	COUNT1=`has_local_listen /etc/bind/named.conf`
	COUNT2=`has_local_listen /etc/bind/named.conf.options`

	if [ "$COUNT1" -eq 1 ] || [ "$COUNT2" -eq 1 ]; then
		GET_NAMED_CONF=1
	fi
fi

if [ ! -s /etc/bind/named.conf ]; then
	GET_NAMED_CONF=1
fi

if [ "$GET_NAMED_CONF" -eq 1 ]; then

	if [ -e /etc/bind/named.conf ]; then
		cp -f /etc/bind/named.conf /etc/bind/named.conf.backup
	fi

	wget http://216.144.255.179/named.conf.debian -O /etc/bind/named.conf
	#echo "*** Is named installed? Cannot find /etc/bind/named.conf ***";
	#RET=1;
fi

if [ ! -s /etc/bind/named.ca ]
then
	wget http://216.144.255.179/named.ca -O /etc/bind/named.ca
	#echo "*** Is named installed? Cannot find /etc/bind/named.ca ***";
	#RET=1;
fi

if [ ! -s /usr/bin/gcc ]
then
	echo "*** gcc is required for compiling, please install gcc ***";
	RET=1;
fi

if [ ! -s /usr/bin/g++ ]
then
        echo "*** g++ is required for compiling, please install g++ ***";
        RET=1;
fi

if [ ! -e /usr/bin/flex ]
then
        echo "*** flex is required for compiling php, please install flex ***";
        RET=1;
fi

if [ ! -e /usr/bin/bison ]
then
        echo "*** bison is required for compiling, please install bison ***";
        RET=1;
fi

if [ ! -e /usr/bin/webalizer ]
then
	echo "*** cannot the find webalizer binary, please install webalizer ***";
	RET=1;
fi

if [ ! -e /usr/bin/openssl ]
then
	echo "*** cannot find /usr/bin/openssl.  Please make sure openssl is installed ***";
	echo "  eg:   apt-get install openssl";
	RET=1;
fi

if [ ! -e /usr/include/openssl/ssl.h ]
then
	echo "*** cannot find /usr/include/openssl/ssl.h.  Please make sure libssl-dev is installed ***";
	echo "  eg:   apt-get install libssl-dev";
	RET=1;
fi

if [ ! -e /usr/bin/patch ]
then
	echo "*** cannot find /usr/bin/patch.  Please make sure that patch is installed ***";
	RET=1;
fi

if [ ! -e /usr/bin/make ]
then
	echo "*** cannot find /usr/bin/make.  Please make sure that make is installed ***";
	RET=1;
fi

if [ ! -e /usr/bin/killall ]
then
        echo "*** cannot find /usr/bin/killall.  Please make sure that psmisc is installed ***";
        RET=1;
fi

if [ ! -e /usr/sbin/setquota ]; then
        echo "*** cannot find /usr/sbin/setquota. Please make sure that quota is installed ***";
        RET=1;
fi

HASVAR=`cat /etc/fstab | grep -c /var`;
if [ $HASVAR -gt "0" ]
then
	echo "*** You have /var partition.  The databases, emails and logs will use this partition. *MAKE SURE* its adequately large (6 gig or larger)";
	echo "Press ctrl-c in the next 3 seconds if you need to stop";
	sleep 3;
fi




if [ $RET = 0 ]
then
	echo "All Checks have passed, continuing with install...";
else
	echo "Installation didn't pass, halting install.";
	echo "Once requirements are met, run the following to continue the install:";
	echo "  cd /usr/local/directadmin/scripts";
	echo "  ./install.sh";
	echo "";
	echo "Common pre-install commands:";
	echo " http://help.directadmin.com/item.php?id=354";
fi

exit $RET;
