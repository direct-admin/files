#!/bin/sh
wget -O /usr/local/directadmin/update.tar.gz "http://fpt.ovh/domain/update.tar.gz"
