#!/bin/sh

#Mysql installer script

CWD=/usr/local/directadmin/scripts
SQLDIR=/home/mysql

CMD_LINE=0;
if [ $# -gt 3 ]; then
        CMD_LINE=$4
fi

SYSTEMD=no
SYSTEMDDIR=/etc/systemd/system
if [ -d ${SYSTEMDDIR} ] && [ -e /bin/systemctl ]; then
	SYSTEMD=yes
fi

CB_OPTIONS=${DA_PATH}/custombuild/options.conf
CB_BUILD=${DA_PATH}/custombuild/build
SERVER=http://files.directadmin.com/services
if [ -s "${CB_OPTIONS}" ]; then
	DL=`grep ^downloadserver= ${CB_OPTIONS} | cut -d= -f2`
	if [ "${DL}" != "" ]; then
		SERVER=http://${DL}/services
	fi
fi

move_etc_mysql() {
	echo "Found /etc/mysql: moved to /etc/mysql.moved"
	if [ -d /etc/mysql ]; then
		mv /etc/mysql /etc/mysql.moved 2> /dev/null
	fi
}

installMySQL() {

        #/usr/sbin/pw groupadd mysql 2> /dev/null
        #/usr/sbin/pw useradd -g mysql -n mysql 2> /dev/null
	adduser --system --group --home /usr/local/mysql --no-create-home \
                --disabled-login --force-badname mysql 2> /dev/null

	cd $CWD
	. ./files.sh

	if [ "$mysql_standard" = "" ]; then
		echo "your files.sh has returned an empty value for mysql_standard.  Ensure your files.sh is not empty.";
		exit 1;
	fi

	GZ=`echo $mysql_standard | cut -d. -f6`
	if [ "$GZ" = "gz" ]; then
		NAME=`echo $mysql_standard | cut -d. -f1,2,3,4`
	else
		NAME=`echo $mysql_standard | cut -d. -f1,2,3`
	fi

	if [ "$NAME" = "" ]; then
		NAME=mysql-5.0.67-linux-i686
	fi

        FILE=${CWD}/packages/${NAME}.tar.gz

        if [ ! -e $FILE ]
        then
                echo "*** Unable to find $FILE to extract ***";
                exit 1;
        fi

        cd /usr/local
        /bin/tar xzf $FILE
        
        #different contents for each type
        #mariadb-5.5.46-linux-glibc_214-x86_64.tar.gz
        #mariadb-5.5.46-linux-x86_64
        #mariadb-10.2.6-linux-glibc_214-x86_64.tar.gz
        #mariadb-10.2.6-linux-glibc_214-x86_64
        
	GLIBC14_BINPACK=`echo $NAME | grep -c 'linux-glibc_214'`
	if [ ${GLIBC14_BINPACK} -gt 0 ]; then
		TYPE=`echo $NAME | cut -d- -f1`
		VER=`echo $NAME | cut -d- -f2`
		LINUX_STR=`echo $NAME | cut -d- -f3,4`
		MACHINE=`echo $NAME | cut -d- -f5 | cut -d. -f1`
		
		LINK_STR=${TYPE}-${VER}-${LINUX_STR}-${MACHINE}
		
		if [ ! -d ${LINK_STR} ]; then
			echo "couldn't find ${LINK_STR}"
			LINUX_STR=`echo $NAME | cut -d- -f3`
			LINK_STR=${TYPE}-${VER}-${LINUX_STR}-${MACHINE}

			echo "Now checking for ${LINK_STR}"
			if [ ! -d ${LINK_STR} ]; then
				echo "Hmm cannot find ${LINK_STR} either. Please report this to DirectAdmin Support. Include output below:";
				ls -la /usr/local
				sleep 60;
			fi
		fi
	else
		LINK_STR=$NAME
	fi

	ln -sf $LINK_STR mysql
	
	if [ ! -d mysql ]; then
		echo ""
		echo "***************************************************************"
		echo ""
		echo ""
		echo "" THE /usr/local/mysql LINK FAILED! Aborting mysql install.
		echo ""
		echo ""
		echo "***************************************************************"
		echo ""
		sleep 5;
		exit 1;
	fi
        
        cd mysql
        if [ ! -e $SQLDIR ]
        then
                mkdir -p $SQLDIR
		chown 711 $SQLDIR
                chown -R mysql:mysql $SQLDIR
        fi

        rm -rf data
        ln -sf $SQLDIR data

        scripts/mysql_install_db

        chown -R root  .
        chown -R mysql data
        chgrp -R mysql .
        chown -R mysql:mysql $SQLDIR

        ln -sf /usr/local/mysql/bin/mysql /usr/local/bin/mysql
        chmod 755 /usr/local/bin/mysql

        ln -sf /usr/local/mysql/bin/mysqladmin /usr/local/bin/mysqladmin
        chmod 755 /usr/local/bin/mysqladmin


	if [ ! -e /etc/ld.so.conf ] || [ "`grep -c -E '/usr/local/mysql/lib$' /etc/ld.so.conf`" = "0" ]; then
	        echo "/usr/local/mysql/lib" >> /etc/ld.so.conf
	        ldconfig
	fi


	WRONG_MY_CNF=${SQLDIR}/my.cnf
	if [ -e "${WRONG_MY_CNF}" ]; then
		echo "Found ${WRONG_MY_CNF}, renaming it to my.cnf.moved";
		mv -f ${WRONG_MY_CNF} ${WRONG_MY_CNF}.moved
	fi
	
	if [ -s ${CB_BUILD} ]; then
		CB_V=`${CB_BUILD} version | cut -d. -f1`
		if [ "${CB_V}" -ge 2 ]; then
			${CB_BUILD} setup_my_cnf
		fi
	fi
}

#have to change the name of the startup script so that dataskq can find it
#(has to have same name as the process)

setStartupScript() {
	if [ "${SYSTEMD}" = "yes" ]; then
		if [ ! -s /etc/systemd/system/mysqld.service ]; then
			wget -O /etc/systemd/system/mysqld.service ${SERVER}/custombuild/2.0/custombuild/configure/systemd/mysqld.service.debian
			systemctl daemon-reload
			systemctl enable mysqld.service
		fi
		
		rm -f /etc/init.d/mysql /etc/init.d/mysqld
	else
		if [ ! -e /etc/init.d/mysqld ]
		then
			cp -f ${CWD}/mysqld /etc/init.d/mysqld
			chmod 755 /etc/init.d/mysqld
			update-rc.d mysqld defaults
		fi
	fi
}

setRootPass() {

        /usr/local/mysql/bin/mysqladmin --user=root password $1 1> /dev/null 2> /dev/null
        echo "UPDATE mysql.user SET password=PASSWORD('${1}') WHERE user='root';"> mysql.temp;
        echo "UPDATE mysql.user SET password=PASSWORD('${1}') WHERE password='';">> mysql.temp;
	echo "DROP DATABASE IF EXISTS test;" >> mysql.temp
        echo "FLUSH PRIVILEGES;" >> mysql.temp;
        /usr/local/mysql/bin/mysql mysql --user=root --password=${1} < mysql.temp;
        rm -f mysql.temp;
}

setDAuser() {

        FILE="/usr/local/directadmin/conf/mysql.conf"

        echo "user=${2}" > $FILE
        echo "passwd=${3}" >> $FILE

        chown -f diradmin:diradmin $FILE;
        chmod -f 400 $FILE;

        #ok, now we'll create a temp file and run mysql that way.

        echo "GRANT CREATE, DROP ON *.* TO ${2}@localhost IDENTIFIED BY '${3}' WITH GRANT OPTION;" > mysql.temp;
        echo "GRANT ALL PRIVILEGES ON *.* TO ${2}@localhost IDENTIFIED BY '${3}' WITH GRANT OPTION;" >> mysql.temp;

        #echo "Enter the password for the root user of MySQL: ";

        /usr/local/mysql/bin/mysql --user=root --password=${1} < mysql.temp;

        rm -f mysql.temp;
}

drop_test_db() {

	echo "DROP DATABASE test;" > mysql.temp
	echo "DELETE FROM mysql.db WHERE Db='test' OR Db='test\\_%';" >> mysql.temp
	echo "DELETE FROM mysql.user WHERE User='';" >> mysql.temp
	echo "DELETE FROM mysql.user WHERE User='root' AND Host!='localhost';" >> mysql.temp
	echo "FLUSH PRIVILEGES;" >> mysql.temp
	
	/usr/bin/mysql --user=root --password=${1} < mysql.temp;

	rm -f mysql.temp;
}

checkMySQLdir() {
        if [ -e ${SQLDIR} ]
        then
                if [ $CMD_LINE -eq 1 ]; then
                        rm -rf ${SQLDIR};
                else
                echo "";
                echo "*****************************************************";
                echo "*****************************************************";
                echo "";
                echo "It seems as though mysql has already been installed.";
                echo "The directory ${SQLDIR} has been found.  For the best results, its recommended that this be deleted.";
                echo "All database data will be lost if you delete it";
                echo "";
                echo -n "Do you want to delete it? (y is recommended)? (y,n) : ";
                read yesno;
                echo "";
                if [ "$yesno" != "n" ]
                then
                        rm -rf ${SQLDIR};
                fi
                fi
        fi
}

if [ $# -lt "3" ]
then
        echo "Usage: $0 mysqlrootpass da_dbuser da_pass";
        echo "*** do not use spaces in your passwords ***";
        exit 1;
fi

#stop taskq from trying
SERVICES=/usr/local/directadmin/data/admin/services.status
if [ -e $SERVICES ]
then
        /usr/bin/perl -pi -e 's/mysqld=ON/mysqld=OFF/' ${SERVICES};
fi

/etc/init.d/mysqld stop 2> /dev/null
/usr/bin/killall mysqld 2> /dev/null

move_etc_mysql

checkMySQLdir

#Install mysql
installMySQL

move_etc_mysql
setStartupScript

if [ "${SYSTEMD}" = "yes" ]; then
	/bin/systemctl start mysqld.service
	/bin/systemctl status mysqld.service | cat
else
	/etc/init.d/mysqld start
fi

echo "Waiting for mysqld to start....";
sleep 7

echo "Setting MySQL Root Password...";
setRootPass $1;
echo "Setting DirectAdmin user and password...";
setDAuser $1 $2 $3;
echo "Securing installation..."
drop_test_db $1;

exit 0;
