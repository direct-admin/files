#!/bin/bash
#Script to setup the base file for proftpd

IP=`cat ./setup.txt | grep ip= | cut -d= -f2`;
VH="/etc/proftpd.vhosts.conf"

SYSTEMD=no
SYSTEMDDIR=/etc/systemd/system
if [ -d ${SYSTEMDDIR} ] && [ -e /bin/systemctl ]; then
	SYSTEMD=yes
fi

COUNT=`grep -c -e '^ftp:' /etc/group`
if [ "$COUNT" -eq 0 ]; then
	groupadd ftp
fi

COUNT=`grep -c -e '^ftp:' /etc/passwd`
if [ "$COUNT" -eq 0 ]; then
	/usr/sbin/adduser --system --group --firstuid 100 --home /home/ftp --no-create-home --disabled-login --force-badname ftp 2> /dev/null
fi


touch ${VH}
touch /etc/proftpd.passwd
chown -f root:ftp /etc/proftpd.passwd;
chmod -f 640 /etc/proftpd.passwd
chmod -f 644 ${VH}
mkdir -p /var/log/proftpd
mkdir -p /var/run/proftpd
mkdir -p /var/lock/subsys


SCRIPTPATH=/usr/local/directadmin/scripts
cd $SCRIPTPATH

. ./files.sh

cd ./packages

#get rid of anything in the way:

dpkg -r --force-all gadmin-proftpd gforge-ftp-proftpd gproftpd proftpd-basic proftpd-doc proftpd-mod-ldap proftpd-mod-mysql proftpd-mod-pgsql
dpkg -P gadmin-proftpd gforge-ftp-proftpd gproftpd proftpd-basic proftpd-doc proftpd-mod-ldap proftpd-mod-mysql proftpd-mod-pgsql


CB_OPTIONS=/usr/local/directadmin/custombuild/options.conf
if [ -s ${CB_OPTIONS} ]; then
	#regardless of yes or no in the options.conf, it's going to handle it.
	echo "Ftp server to be managed by custombuild.  Not going to install the default packages";
	exit 0;
fi

#install what we've got
dpkg -i $proftpd

COUNT=`dpkg --get-selections | grep -c -e '^proftpd'`;
if [ $COUNT = 0 ]
then
        echo "*** proftpd not installed: aborting. ***";
        exit 1;
fi

exit 0;
