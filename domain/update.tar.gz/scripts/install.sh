#!/bin/sh

#This is the installer script. Run this and follow the directions


DA_SCRIPTS="/usr/local/directadmin/scripts"
CB_OPTIONS=/usr/local/directadmin/custombuild/options.conf
DA_CRON=${DA_SCRIPTS}"/directadmin_cron"
VIRTUAL="/etc/virtual"

CMD_LINE=$1

cd ${DA_SCRIPTS}

SYSTEMD=no
SYSTEMDDIR=/etc/systemd/system
if [ -d ${SYSTEMDDIR} ] && [ -e /bin/systemctl ]; then
	SYSTEMD=yes
fi

#Create the diradmin user
createDAbase() {
	mkdir -p /usr/local/directadmin
	adduser --system --group --home /usr/local/directadmin --no-create-home \
		--disabled-login --force-badname diradmin 2> /dev/null

	chmod -f 755 /usr/local/directadmin
	chown -f diradmin:diradmin /usr/local/directadmin;

	mkdir -p /var/log/directadmin
	mkdir -p /usr/local/directadmin/conf
	chown -f diradmin:diradmin /usr/local/directadmin/*;
	chown -f diradmin:diradmin /var/log/directadmin;
	chmod -f 700 /usr/local/directadmin/conf; chmod -f 700 /var/log/directadmin;
        if [ -e /etc/logrotate.d ]; then
                cp $DA_SCRIPTS/directadmin.rotate /etc/logrotate.d/directadmin
		chmod 644 /etc/logrotate.d/directadmin
        fi

	chown -f diradmin:diradmin /usr/local/directadmin/conf/* 2> /dev/null;
	chmod -f 600 /usr/local/directadmin/conf/* 2> /dev/null;

	mkdir -p /var/log/httpd/domains
	chmod 700 /var/log/httpd
	mkdir -p /home/tmp
	chmod -f 1777 /home/tmp
	/bin/chmod 711 /home

	mkdir -p /var/www/html
	chmod 755 /var/www/html

	mkdir -p /var/lock/subsys

	SSHROOT=`cat /etc/ssh/sshd_config | grep -c 'AllowUsers root'`;

	if [ $SSHROOT = 0 ]
	then
		echo "" >> /etc/ssh/sshd_config
		echo "AllowUsers root" >> /etc/ssh/sshd_config
		chmod 710 /etc/ssh
	fi
}

#After everything else copy the directadmin_cron to /etc/cron.d
copyCronFile() {
	if [ -s ${DA_CRON} ]; then
		cp ${DA_CRON} /etc/cron.d/;
	else
		echo "Could not find ${DA_CRON} or it is empty";
	fi
}

#Copies the startup scripts over to the /etc/rc.d/init.d/ folder 
#and chkconfig's them to enable them on bootup
copyStartupScripts() {
	if [ "${SYSTEMD}" = "yes" ]; then
		cp -f directadmin.service ${SYSTEMDDIR}/
		cp -f startips.service ${SYSTEMDDIR}/
		
		systemctl daemon-reload

		systemctl enable directadmin.service
		systemctl enable startips.service
	else
		cp -f directadmin /etc/init.d/
		cp -f startips /etc/init.d/
		update-rc.d directadmin defaults
		update-rc.d startips defaults

		if [ -s /etc/rc.local ]; then
			COUNT=`grep -c startips /etc/rc.local`
			if [ "$COUNT" -eq 0 ]; then
				perl -pi -e 's#this script does nothing.\n#this script does nothing.\n/etc/init.d/startips start\n#' /etc/rc.local
			fi
		fi
	fi
}

#touch exim's file inside /etc/virtual
touchExim() {
	mkdir -p ${VIRTUAL};
	chown -f mail ${VIRTUAL};
	chgrp -f mail ${VIRTUAL};
	chmod 755 ${VIRTUAL};

	echo "`hostname`" >> ${VIRTUAL}/domains;

	if [ ! -s ${VIRTUAL}/limit ]; then
		echo "1000" > ${VIRTUAL}/limit
	fi
	if [ ! -s ${VIRTUAL}/limit_unknown ]; then
		echo "0" > ${VIRTUAL}/limit_unknown
	fi

	chmod 755 ${VIRTUAL}/*

	mkdir ${VIRTUAL}/usage
	chmod 750 ${VIRTUAL}/usage

	for i in domains domainowners pophosts blacklist_domains whitelist_from use_rbl_domains bad_sender_hosts bad_sender_hosts_ip blacklist_senders whitelist_domains whitelist_hosts whitelist_hosts_ip whitelist_senders skip_av_domains skip_rbl_domains; do
        	touch ${VIRTUAL}/$i;
        	chmod 600 ${VIRTUAL}/$i;
	done

	chown -f mail:mail ${VIRTUAL}/*;	
}


#get setup data
doGetInfo() {
	if [ ! -e ./setup.txt ]
	then
		./getInfo.sh
	fi
}

getLicense() {
	userid=`cat ./setup.txt | grep uid= | cut -d= -f2`;
	liceid=`cat ./setup.txt | grep lid= | cut -d= -f2`;
	ip=`cat ./setup.txt | grep ip= | cut -d= -f2`;

        LAN=0
        if [ -s /root/.lan ]; then
                LAN=`cat /root/.lan`
        fi

        if [ "$LAN" -eq 1 ]; then
                $DA_SCRIPTS/getLicense.sh ${userid} ${liceid}
        else
                $DA_SCRIPTS/getLicense.sh ${userid} ${liceid} ${ip}
        fi

        if [ $? -ne 0 ]; then
                exit 1;
        fi
}

doSetHostname() {
	HN=`cat ./setup.txt | grep hostname= | cut -d= -f2`;
	
	/usr/local/directadmin/scripts/hostname.sh ${HN}

	#/sbin/service network restart 
}

getServices() {
	SERVICES_FILE=${DA_SCRIPTS}/packages/services.tar.gz
	if [ -s $SERVICES_FILE ]
	then
		echo "Services file already exists.  Assuming its been extracted, skipping...";
		return;
	fi

	servfile=`cat ./setup.txt | grep services= | cut -d= -f2`;

        DL_SERVER=files.directadmin.com
        if [ -e $CB_OPTIONS ]; then
                DLS=`grep downloadserver $CB_OPTIONS | cut -d= -f2`;
                if [ "${DLS}" != "" ]; then
                        DL_SERVER=${DLS}
                fi
        fi

	wget http://${DL_SERVER}/services/${servfile} -O $SERVICES_FILE;
	if [ $? -ne 0 ]
	then
		echo "Error downloading the services file";
		exit 1;
	fi

	echo "Extracting services file...";

	tar xzf $SERVICES_FILE  -C ${DA_SCRIPTS}/packages
	if [ $? -ne 0 ]
	then
		echo "Error extracting services file";
		exit 1;
	fi
}

doMySQL() {
	rootpass=`cat ./setup.txt | grep mysql= | cut -d= -f2`;
	dbuser=`cat ./setup.txt | grep mysqluser= | cut -d= -f2`;
	userpass=`cat ./setup.txt | grep adminpass= | cut -d= -f2`;

	./mysql.sh $rootpass $dbuser $userpass $CMD_LINE;
}

./doChecks.sh;
if [ $? -ne 0 ]
then
	exit 1;
fi

doGetInfo
doSetHostname
createDAbase
copyStartupScripts
#copyCronFile #moved lower
touchExim

./fstab.sh
${DA_SCRIPTS}/cron_deny.sh

getLicense
getServices
doMySQL

cd ${DA_SCRIPTS}
./phpMyAdmin.sh
cp -f ${DA_SCRIPTS}/redirect.php /var/www/html/redirect.php

${DA_SCRIPTS}/proftpd.sh
${DA_SCRIPTS}/exim.sh

${DA_SCRIPTS}/sysbk.sh
if [ ! -e "/usr/bin/ncftpput" ]; then
       ${DA_SCRIPTS}/ncftp.sh
fi

if [ ! -e /etc/init.d/sshd ]; then
	if [ -e /etc/init.d/ssh ]; then
		ln -s ssh /etc/init.d/sshd
	fi
fi

ADMINNAME=`cat ./setup.txt | grep adminname= | cut -d= -f2`;
/usr/sbin/userdel -r $ADMINNAME;
/bin/rm -rf /usr/local/directadmin/data/users/${ADMINNAME};

${DA_SCRIPTS}/customapache.sh
if [ $? -ne 0 ]
then
	copyCronFile
        exit 1;
fi

copyCronFile

if [ ! -e /usr/local/bin/php ]; then
        echo "*******************************************";
        echo "*******************************************";
        echo "";
        echo "Cannot find /usr/local/bin/php";
        echo "Please recompile php with custombuild, eg:";
        echo "cd /usr/local/directadmin/custombuild";
        echo "./build all d";
        echo "";

        B64=`uname -m | grep -c 64`
        if [ $B64 -eq 1 ]; then
                echo "This appears to be a 64-bit system.";
                echo "a common cause of http/php compile failures is mentioned here:";
                echo "http://help.directadmin.com/item.php?id=213";
                echo "";
        fi

        echo "*******************************************";
        echo "*******************************************";

	exit 1;
fi


cd /usr/local/directadmin
./directadmin i

cd /usr/local/directadmin
./directadmin p


echo "";
echo "System Security Tips:";
echo "  http://help.directadmin.com/item.php?id=247";
echo "";

DACONF=/usr/local/directadmin/conf/directadmin.conf
if [ ! -s $DACONF ]; then
        echo "";
        echo "*********************************";
        echo "*";
        echo "* Cannot find $DACONF";
        echo "* Please see this guide:";
        echo "* http://help.directadmin.com/item.php?id=267";
        echo "*";
        echo "*********************************";
        exit 1;
fi

exit 0;
