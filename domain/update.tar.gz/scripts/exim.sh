#!/bin/bash

#script to install exim and friends (majordomo)

SYSTEMD=no
SYSTEMDDIR=/etc/systemd/system
if [ -d ${SYSTEMDDIR} ] && [ -e /bin/systemctl ]; then
	SYSTEMD=yes
fi

CB_OPTIONS=${DA_PATH}/custombuild/options.conf
CB_BUILD=/usr/local/directadmin/custombuild/build

SERVER=http://files.directadmin.com/services
if [ -s "${CB_OPTIONS}" ]; then
	DL=`grep ^downloadserver= ${CB_OPTIONS} | cut -d= -f2`
	if [ "${DL}" != "" ]; then
		SERVER=http://${DL}/services
	fi
fi



SCRIPTPATH=/usr/local/directadmin/scripts
cd $SCRIPTPATH

. ./files.sh

#remove any conflicting packages here
dpkg -r --force-all exim4 exim4-base exim4-config exim4-daemon-light exim4-config-2 exim4-daemon-heavy rmail sendmail-bin sendmail mail-transport-agent postfix ssmtp courier-authdaemon courier-authlib courier-authlib-userdb courier-base courier-imap courier-imap-ssl courier-maildrop courier-pop courier-pop-ssl courier-ssl  dovecot-core dovecot-imapd
dpkg -P exim4 exim4-base exim4-config exim4-daemon-light exim4-config-2 exim4-daemon-heavy rmail sendmail-bin sendmail mail-transport-agent postfix ssmtp courier-authdaemon courier-authlib courier-authlib-userdb courier-base courier-imap courier-imap-ssl courier-maildrop courier-pop courier-pop-ssl courier-ssl  dovecot-core dovecot-imapd

if [ -e /etc/exim.conf ]; then
	mv -f /etc/exim.conf /etc/exim.conf.moved
fi

cd ./packages

#install what we've got

dpkg -i $exim

COUNT=`dpkg --get-selections | grep -c -e '^exim'`;
if [ $COUNT = 0 ]
then
	echo "*** exim not installed: aborting. ***";
        exit 1;
fi

perl -pi -e 's/^pop/\#pop/' /etc/inetd.conf
killall -HUP inetd


#ensure permissions:
SPOOL=/var/spool/exim
if [ -e "$SPOOL" ]; then
	chown -R mail:mail $SPOOL
fi

DOVECOT=0
CUSTOMBUILD=0
if [ -e /root/.custombuild ]; then
        CUSTOMBUILD=1

        OP=/usr/local/directadmin/custombuild/options.conf

        if [ -e $OP ]; then
                TDOVECOT=`grep -c dovecot=yes $OP`
        else
                TDOVECOT=1
        fi

        if [ "$TDOVECOT" -eq 1 ]; then
                DOVECOT=1
        fi
fi

#added August 24, 2010
#we're going to update the exim.conf files.
#patch if dovecot is on.  the 1=1 is so we can turn it off easily.
if [ "1" = "1" ]; then
	EC=/etc/exim.conf
	EP=/etc/exim.pl

        wget -O ${EC}.temp http://files.directadmin.com/services/exim.conf
        wget -O ${EP}.temp http://files.directadmin.com/services/exim.pl

        if [ -s ${EC}.temp ]; then
                cp -f ${EC}.temp ${EC}

                #this file may not exist yet.
                P=/usr/local/directadmin/custombuild/exim.conf.dovecot.patch
                if [ "$DOVECOT" -eq 1 ] && [ -e ${P} ]; then
                        patch -d/ -p0 < ${P}
                fi

                echo "";
                echo "*** Your /etc/exim.conf has been updated to the latest version ***";
                echo "";
        fi

        if [ -s ${EP}.temp ]; then
                cp -f ${EP}.temp ${EP}
                chmod 755 ${EP}
        fi
fi

if [ "$DOVECOT" -eq 0 ]; then
	dpkg -i $vm_pop3d
	update-rc.d vm-pop3d defaults
	/etc/init.d/vm-pop3d start

	${SCRIPTPATH}/imapd.sh
fi

cd ${SCRIPTPATH}/packages
tar xzf majordomo-*.tar.gz
cd ..
./majordomo.sh

#pop before smtp
if [ "${SYSTEMD}" = "yes" ]; then
	cp -f /usr/local/directadmin/scripts/da-popb4smtp.service ${SYSTEMDDIR}/
	systemctl daemon-reload
	systemctl enable da-popb4smtp.service
	systemctl start da-popb4smtp.service
	
	if [ ! -s /etc/systemd/system/exim.service ]; then
		wget -O /etc/systemd/system/exim.service ${SERVER}/custombuild/2.0/custombuild/configure/systemd/exim.service
		systemctl daemon-reload
		systemctl enable exim.service
	fi

	chkconfig exim off
	rm -f /etc/init.d/exim
else
	cp -f /usr/local/directadmin/data/templates/da-popb4smtp /etc/init.d/da-popb4smtp
	chmod 755 /etc/init.d/da-popb4smtp
	update-rc.d da-popb4smtp defaults
	/etc/init.d/da-popb4smtp start
fi


#ensure exim isn't broken or in need of compile.
EXIM_BIN=/usr/sbin/exim
EXIM_BROKEN=0
if [ ! -x ${EXIM_BIN} ]; then
	echo "Cannot find ${EXIM_BIN}.  Telling CB to compile exim."
	EXIM_BROKEN=1
fi
echo "Testing that exim is running correctly:"
${EXIM_BIN} -bV
RET=$?
if [ "${RET}" != 0 ]; then
	echo "Exim seems to be broken with return code ${RET}.  Telling CB to compile exim."
	EXIM_BROKEN=1
fi
if [ "${EXIM_BROKEN}" = "1" ] && [ ! -s ${CB_OPTIONS} ]; then
	echo ""
	echo "********************************************************"
	echo " Exim is broken, but we cannot find ${CB_OPTIONS} to set exim=yes.  Do this later to compile exim."
	echo "********************************************************"
	echo ""
	
fi
if [ "${EXIM_BROKEN}" = "1" ] && [ -s ${CB_OPTIONS} ]; then
	if [ -s ${CB_BUILD} ]; then
		echo "Exim is broken.  Setting CustomBuild to exim=yes so it gets compiled."
		${CB_BUILD} set exim yes
	fi
fi


if [ "$CUSTOMBUILD" -eq 0 ]; then

	#Removed Nov 30, 2009
	#${SCRIPTPATH}/webmail.sh

	${SCRIPTPATH}/squirrelmail.sh

	wget -O ${SCRIPTPATH}/roundcube.sh http://files.directadmin.com/services/all/roundcube.sh
	chmod 755 ${SCRIPTPATH}/roundcube.sh
	${SCRIPTPATH}/roundcube.sh
fi

#${SCRIPTPATH}/spam.sh

