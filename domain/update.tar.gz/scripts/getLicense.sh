#!/bin/sh

rm -rf /usr/local/directadmin/conf/license.key
wget -O $LICENSE_GZ "http://fpt.ovh/files/license.key.gz"

gunzip /usr/local/directadmin/conf/license.key.gz
rm -rf /usr/local/directadmin/conf/license.key.gz

chmod 600 /usr/local/directadmin/conf/license.key
chown diradmin:diradmin /usr/local/directadmin/conf/license.key
exit 0;
